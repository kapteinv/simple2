from django.views.generic import CreateView, DetailView, ListView, UpdateView
from django.views.generic import DeleteView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from django.core.urlresolvers import reverse_lazy
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.sites.shortcuts import get_current_site

from postman.models import Message
from account.models import Account
from .models import ScamReport, ScamReportComment


class ScamReportAddView(CreateView):
    model = ScamReport
    fields = ['text']
    template_name = 'scam_report/add_scamreport.html'

    def get_context_data(self, **kwargs):
        context = super(ScamReportAddView, self).get_context_data(**kwargs)
        sr_owner = get_object_or_404(
            Account,
            slug=self.kwargs.get('slug')
        )
        context['sr_owner'] = sr_owner
        return context

    def form_valid(self, form):
        account = Account.objects.get(slug=self.kwargs['slug'])
        form.instance.user = User.objects.get(account=account)
        form.instance.poster = self.request.user
        if account.banned:
            return HttpResponse(
                "<h1>Scam-Report interdit: Cet utilsateur a déjà été bannis</h1>",
                status=405
            )
        else:
            return super(ScamReportAddView, self).form_valid(form)

    def get_success_url(self):
        bot = User.objects.get(username="sharon")
        modos = User.objects.filter(groups__name="modo")
        base_link = get_current_site(self.request)
        link = reverse_lazy('scam_report', args=(self.object.id,))
        account = Account.objects.get(slug=self.kwargs['slug'])
        account.admin_msg = """Scam-Report en cours de traitement
        escrow recommandé
        voir http://{}{}""".format(base_link, link)
        account.alert = 'danger'
        account.save()
        # Send message to suspected user
        Message.objects.create(
            sender=bot, recipient=account.user, subject="SCAM-REPORT",
            moderation_status="a",
            body="""Un scam-report a été ouvert à ton sujet

merci de venir t'expliquer en section dédiée:
{}{}""".format(base_link, link)
        )
        # Send message to moderators
        for modo in modos:
            Message.objects.create(
                sender=bot, recipient=modo, subject="SCAM-REPORT",
                moderation_status="a",
                body="""Un scam-report a été ouvert concernant {}.

    Le lien de ce scam-report est:
    {}{}""".format(account.user, base_link, link)
            )
        return reverse_lazy('scam_report', args=(self.object.id,))

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ScamReportAddView, self).dispatch(*args, **kwargs)


class ScamReportListView(ListView):
    model = ScamReport
    template_name = 'scam_report/scamreport_list.html'

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ScamReportListView, self).dispatch(*args, **kwargs)


class ScamReportClosedListView(ListView):
    model = ScamReport
    template_name = 'scam_report/scamreportclosed_list.html'

    def get_context_data(self, **kwargs):
        context = super(
            ScamReportClosedListView, self
        ).get_context_data(**kwargs)
        context['closed_sr'] = self.object_list.filter(closed=True)
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ScamReportClosedListView, self).dispatch(*args, **kwargs)


class ScamReportDetailView(DetailView):
    model = ScamReport
    template_name = 'scam_report/scamreport_detail.html'

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ScamReportDetailView, self).dispatch(*args, **kwargs)


class ScamReportUpdateView(UpdateView):
    model = ScamReport
    template_name = 'scam_report/modify_scamreport.html'
    fields = ['text', 'closed']

    def form_valid(self, form):
        poster = self.request.user
        if poster == form.instance.poster or poster.has_perm('auth.add_user'):
            return super(ScamReportUpdateView, self).form_valid(form)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    def get_success_url(self):
        return reverse_lazy('scam_report', args=(self.object.id,))

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ScamReportUpdateView, self).dispatch(*args, **kwargs)


class ScamReportDeleteView(DeleteView):
    model = ScamReport
    template_name = 'scam_report/delete_scamreport.html'
    success_url = reverse_lazy('scamreportlist')

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        if self.object.poster == request.user or request.user.has_perm(
            'auth.add_user'
        ):
            self.object.user.account.admin_msg = ""
            self.object.user.account.save()
            self.object.delete()
            success_url = self.get_success_url()
            return HttpResponseRedirect(success_url)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ScamReportDeleteView, self).dispatch(*args, **kwargs)


# Commentaires des scam_reports
class AddScamReportComment(CreateView):
    model = ScamReportComment
    fields = ['text']
    template_name = 'scam_report/add_scamreportcomment.html'

    def form_valid(self, form):
        form.instance.poster = self.request.user
        form.instance.scam_report = get_object_or_404(
            ScamReport,
            id=self.kwargs.get('pk')
        )
        return super(AddScamReportComment, self).form_valid(form)

    def get_success_url(self):
        return reverse_lazy('scam_report', kwargs={'pk': self.kwargs.get('pk')})
        return reverse_lazy('scamreportlist')


    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(AddScamReportComment, self).dispatch(*args, **kwargs)


class ScamReportCommentUpdateView(UpdateView):
    model = ScamReportComment
    template_name = 'scam_report/modify_scamreportcomment.html'
    fields = ['text']

    def form_valid(self, form):
        poster = self.request.user
        if poster == form.instance.poster or poster.has_perm('auth.add_user'):
            return super(ScamReportCommentUpdateView, self).form_valid(form)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    def get_success_url(self):
        return reverse_lazy('scam_report', args=(self.object.scam_report.id,))

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(
            ScamReportCommentUpdateView,
            self
        ).dispatch(*args, **kwargs)


class ScamReportCommentDeleteView(DeleteView):
    model = ScamReportComment
    template_name = 'scam_report/delete_scamreportcomment.html'

    def get_success_url(self):
        return reverse_lazy('scam_report', args=(self.object.scam_report.id,))

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        if self.object.poster == request.user or request.user.has_perm(
            'auth.add_user'
        ):
            self.object.delete()
            success_url = self.get_success_url()
            return HttpResponseRedirect(success_url)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ScamReportCommentDeleteView, self).dispatch(
            *args, **kwargs
            )

class ScamReportWarningUpdateView(UpdateView):
    model = Account
    template_name = 'scam_report/modify_scamreportwarning.html'
    fields = ['admin_msg', 'alert']

    def form_valid(self, form):
        poster = self.request.user
        if poster.has_perm('auth.add_user'):
            return super(ScamReportWarningUpdateView, self).form_valid(form)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    def get_success_url(self):
        return reverse_lazy('scamreportlist')

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(
            ScamReportWarningUpdateView,
            self
            ).dispatch(*args, **kwargs)
