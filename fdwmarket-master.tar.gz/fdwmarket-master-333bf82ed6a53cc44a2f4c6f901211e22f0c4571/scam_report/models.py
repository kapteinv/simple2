from django.db import models
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse


class ScamReport(models.Model):

    user = models.ForeignKey(User, related_name="scam_report")
    poster = models.ForeignKey(User)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    closed = models.BooleanField(default=False)
    text = models.TextField(blank=True, default='')

    def get_absolute_url(self):
        return reverse('scam_report', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.user)


class ScamReportComment(models.Model):

    scam_report = models.ForeignKey(
        ScamReport, blank=True, null=True, related_name='comments'
    )
    poster = models.ForeignKey(User)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    text = models.TextField(blank=True, default='')

    def __str__(self):
        return str(self.feedback)
