from django.conf.urls import url
from .views import ScamReportAddView, ScamReportDetailView, ScamReportListView
from .views import ScamReportClosedListView, ScamReportUpdateView, ScamReportDeleteView
from .views import AddScamReportComment, ScamReportCommentUpdateView
from .views import ScamReportCommentDeleteView, ScamReportWarningUpdateView

urlpatterns = [
    url(
        r'^add/(?P<slug>[-_\w]+)/$',
        ScamReportAddView.as_view(),
        name="add_scamreport"
        ),
    url(
        r'^scam_report/(?P<pk>[0-9]+)/$',
        ScamReportDetailView.as_view(),
        name="scam_report"
        ),
    url(
        r'^scamreport_list/$',
        ScamReportListView.as_view(),
        name="scamreportlist"
        ),
    url(
        r'^scamreportclosed_list/$',
        ScamReportClosedListView.as_view(),
        name="scamreportclosedlist"
        ),
    url(
        r'^scam_report/modify/(?P<pk>[0-9]+)/$',
        ScamReportUpdateView.as_view(),
        name="modify_scamreport"
        ),
    url(
        r'^scam_report/delete/(?P<pk>[0-9]+)/$',
        ScamReportDeleteView.as_view(),
        name="delete_scamreport"
        ),
    url(
        r'^add_comment/(?P<pk>[-_\w]+)/$',
        AddScamReportComment.as_view(),
        name="add_scamreportcomment"
        ),
    url(
        r'^modify/comment/(?P<pk>[0-9]+)/$',
        ScamReportCommentUpdateView.as_view(),
        name="modify_scamreportcomment"
        ),
    url(
        r'^delete/comment/(?P<pk>[0-9]+)/$',
        ScamReportCommentDeleteView.as_view(),
        name="delete_scamreportcomment"
        ),
    url(
        r'^modify/warning_message/(?P<slug>[-_\w]+)/$',
        ScamReportWarningUpdateView.as_view(),
        name="modify_scamreportwarning"
        ),
]
