from django.contrib import admin

from .models import ScamReport


class ScamReportAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'user', 'poster', 'created_at', 'updated_at', 'closed', 'text'
    )
    search_fields = ('user__username', 'poster__username')

admin.site.register(ScamReport, ScamReportAdmin)
