from django.apps import AppConfig


class ScamReportConfig(AppConfig):
    name = 'scam_report'
