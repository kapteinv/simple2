import datetime

from django.core.management.base import BaseCommand
from django.utils import timezone
from postman.models import Message


class Command(BaseCommand):
    help = (
        'Deletes messages that have been marked as deleted by both the sender'
        'and recipient and messages older than a maximum age. You must provide'
        'the minimum age in days since the message was deleted and the maximum'
        'age in days the message was sent.'
    )

    def add_arguments(self, parser):
        parser.add_argument(
            'age_in_days',
            type=int,
            help='minimum age in days since the message was deleted from the 2 sides '
        )
        parser.add_argument(
            'max_age_in_days',
            type=int,
            help='maximum age in days since the message was sent'
        )

    def handle(self, *args, **options):
        the_date = timezone.now() - datetime.timedelta(
            days=options['age_in_days']
            )
        the_date2 = timezone.now() - datetime.timedelta(
            days=options['max_age_in_days']
            )

        Message.objects.filter(
            recipient_deleted_at__lte=the_date,
            sender_deleted_at__lte=the_date,
        ).delete()

        Message.objects.filter(sent_at__lte=the_date2).delete()
