import datetime
from django.core.management.base import BaseCommand
from django.utils import timezone
from django.contrib.auth.models import User
from shops.models import Shop, Product


class Command(BaseCommand):
    help = (
        'Deativate users not connected since <last_log> days '
        'or never active since <never_log> days, delete related shop, products '
        'and feedbacks'
    )

    def add_arguments(self, parser):
        parser.add_argument(
            'last_log',
            type=int,
            help='days since the user not log-in'
        )
        parser.add_argument(
            'never_log',
            type=int,
            help='days since the user never log-in'
        )

    def handle(self, *args, **options):

        comp1 = 0
        comp2 = 0
        now = timezone.now()
        vendors = []
        prods = []
        for user in User.objects.filter(account__banned=False):

            try:
                if now - user.last_login > datetime.timedelta(days=options['last_log']):
                    try:
                        shop = Shop.objects.get(name=user)
                        vendors.append(shop)
                        shop.delete()
                    except Shop.DoesNotExist:
                        pass

                    try:
                        for prod in Product.objects.filter(shop=user):
                            prods.append(prod)
                            prod.delete()
                    except Product.DoesNotExist:
                        pass

                    user.is_active = False
                    user.save()
                    user.account.inactive = True
                    user.account.admin_msg += """
                    Compte désactivé pour inactivité.
                    Cet utilisateur ne s'est plus connecté depuis plus de 90 jours.
                    """
                    user.account.save()
                    comp1 += 1

            except TypeError:
                if now - user.date_joined > datetime.timedelta(days=options['never_log']):
                    user.is_active = False
                    user.save()
                    user.account.inactive = True
                    user.account.admin_msg += """
                    Compte désactivé pour inactivité
                    Plus de 90 jours après la création du compte cet utilisateur ne s'est jamais connecté
                    """
                    user.account.save()
                    comp2 += 1
        print()
        print(comp1, "utilisateurs désactivés car ne sont pas connectés depuis plus de 90 jours")
        print("dont {} vendeurs".format(len(vendors)))
        print("un total de {} produits mis en ligne par ces vendeurs ont été supprimés".format(len(prods)))
        print(comp2, "utilisateurs désactivés car ne se sont toujours pas connécté au market 90 jours après avoir créé leur compte")
