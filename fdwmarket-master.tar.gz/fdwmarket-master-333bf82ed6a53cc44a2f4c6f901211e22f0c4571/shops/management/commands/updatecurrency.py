from django.core.management.base import BaseCommand
from django.core.exceptions import ObjectDoesNotExist

from shops.getBTCrate import GetBtc
from shops.models import Currency


class Command(BaseCommand):

    help = 'update currency from API like bitcoinaverage, you need to set \
the url of the API'

    def handle(self, **options):
        change = GetBtc(
            "https://apiv2.bitcoinaverage.com/indices/global/ticker/BTCEUR"
            )
        try:
            c = Currency.objects.get(name="euro")
        except ObjectDoesNotExist:
            c = Currency(name="euro")
        c.btc_to_currency = change.exchange()
        c.currency_to_btc = 1 / c.btc_to_currency
        c.save()
