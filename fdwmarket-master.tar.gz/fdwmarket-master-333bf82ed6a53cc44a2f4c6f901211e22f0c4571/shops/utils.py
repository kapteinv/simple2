"""
Helpers for the shop app.

http://mathieu.agopian.info/blog/django-redimensionner-une-image-a-la-volee-en-preservant-son-ratio.html

"""
from io import BytesIO
from django.core.files.uploadedfile import SimpleUploadedFile
from PIL import Image


def create_thumb(image, size):
    """Returns the image resized to fit inside a box of the given size."""
    image.thumbnail(size, Image.ANTIALIAS)
    temp = BytesIO()
    image.save(temp, 'jpeg')
    temp.seek(0)
    return SimpleUploadedFile('temp', temp.read())

def has_changed(instance, field, manager='objects'):
    """
    Returns true if a field has changed in a model.

    May be used in a model.save() method.
    """
    if not instance.pk:
        return True
    manager = getattr(instance.__class__, manager)
    old = getattr(manager.get(pk=instance.pk), field)
    return not getattr(instance, field) == old
