# -*- coding: utf-8 -*-
from django.contrib import admin
from shops.models import Shop, Category, Product, Currency, Publicity, AcceptedCurrencies


class ShopAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug')
    search_fields = ('name__username', 'slug')


class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'shop', 'category')
    search_fields = ('name', 'shop__username')
    list_filter = (
        ('category', admin.RelatedOnlyFieldListFilter),
    )


class PublicityAdmin(admin.ModelAdmin):
    list_display = ('name', 'user', 'due_date', 'end_date', 'note', 'active')
    ordering = ('-active',)


admin.site.register(Shop, ShopAdmin)
admin.site.register(Category)
admin.site.register(Product, ProductAdmin)
admin.site.register(Publicity, PublicityAdmin)
admin.site.register(Currency)
admin.site.register(AcceptedCurrencies)
