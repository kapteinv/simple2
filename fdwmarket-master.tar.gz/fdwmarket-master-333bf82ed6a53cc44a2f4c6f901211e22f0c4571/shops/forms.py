from django import forms
from django.forms import ModelForm
from django.core.exceptions import ValidationError


from .models import Product, Category, Shop

EMPTY_PRODUCT_NAME_ERROR = "Un nom de produit est obligatoire."


class ProductForm(ModelForm):

    class Meta:
        model = Product
        fields = ('name', 'shop', 'category', 'photo', 'price_in_euros')
        widgets = {
            'name': forms.fields.TextInput(attrs={
                'placeholder': 'Un nom de produit',
                'class': 'form-control input-lg',
            }),
        }
        error_messages = {
            'name': {'required': EMPTY_PRODUCT_NAME_ERROR},
            #   'negative_price': _("The price need to be positive")
        }

    def save(self, for_shop):
        self.instance.shop = for_shop
        return super().save()


class CategoryForm(ModelForm):

    class Meta:
        model = Category
        fields = ('parent', 'name')
        widgets = {
            'name': forms.fields.TextInput(attrs={
                'placeholder': 'Un nom de produit',
                'class': 'form-control input-lg',
            }),
        }
        error_messages = {
            'name': {'required': EMPTY_PRODUCT_NAME_ERROR}
        }

    def save(self, for_shop):
        self.instance.shop = for_shop
        return super().save()


class ShopForm(ModelForm):

    class Meta:
        model = Shop
        fields = ['enseigne', 'description']
        widgets = {
            'name': forms.fields.TextInput(attrs={
                'placeholder': 'Un nom de produit',
                'class': 'form-control input-lg',
            }),
        }
        error_messages = {
            'name': {'required': EMPTY_PRODUCT_NAME_ERROR}
        }

    def save(self, for_shop):
        self.instance.shop = for_shop
        return super().save()
