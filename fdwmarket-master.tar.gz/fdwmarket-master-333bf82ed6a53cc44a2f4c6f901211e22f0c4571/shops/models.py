from datetime import date
#  import subprocess
import os
import sys

from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator
# from django.core.files.uploadedfile import SimpleUploadedFile
from autoslug import AutoSlugField
from PIL import Image
from .utils import create_thumb, has_changed
# Test if we are in prod or in test environment for import the MEDIA_ROOT
if sys.version_info < (3, 6):
    ModuleNotFoundError = ImportError
try:
    from fdwmarket.settings.prod import MEDIA_ROOT, MEDIA_URL
except ModuleNotFoundError:
    from fdwmarket.settings.test import MEDIA_ROOT, MEDIA_URL



class AcceptedCurrencies(models.Model):
    name = models.CharField(max_length=20, blank=True)

    def __str__(self):
        return str(self.name)


class Shop(models.Model):

    name = models.OneToOneField(User)
    slug = AutoSlugField(populate_from='name', unique=True)
    enseigne = models.ImageField(upload_to='shop_enseigne',
                                 blank=True, null=True)
    escrow_accepted = models.BooleanField(default=False)
    description = models.TextField(default='')
    accepted_currencies = models.ManyToManyField(AcceptedCurrencies, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if has_changed(self, 'enseigne'):
            # on va convertir l'image en jpg
            f, e = os.path.splitext(str(self.enseigne.name))
            filename = "{}.jpg".format(f)

            # Ne fait rien si pas d'image
            try:
                image = Image.open(self.enseigne.file)

                if image.mode not in ('L', 'RGB'):
                    image = image.convert('RGB')

                # pré-sauvegarde de la photo modifié
                self.enseigne.save(
                    filename,
                    create_thumb(image, (500, 180)),
                    save=False
                )
            except ValueError:
                pass

        super(Shop, self).save(*args, **kwargs)

    def __str__(self):
        return str(self.name)


class Category(models.Model):
    parent = models.ForeignKey('self', blank=True, null=True,
                               related_name='children')
    name = models.CharField(max_length=300, unique=True)
    slug = AutoSlugField(populate_from='name', unique=True)

    class Meta:
        verbose_name_plural = "categories"

    def __str__(self):
        return self.name


# sorted categories helper
class CatName:

    """class used for categories displaying"""
    def __init__(self, name, slug):
        self.name = name
        self.slug = slug


def sorted(cat):

    sortedCat = []
    for c in cat:
        if c.parent is None:
            sortedCat.append(CatName(c.name, c.slug))
            for i in c.children.all():
                sortedCat.append(CatName("-- " + i.name, i.slug))
    return sortedCat
##


class Product(models.Model):
    shop = models.ForeignKey(User)
    category = models.ForeignKey('Category', default='')
    name = models.CharField(max_length=300, default='')
    slug = AutoSlugField(populate_from='name', unique=True)
    description = models.TextField(default='')
    photo = models.ImageField(upload_to='product_photo',
                              blank=True)
    # views = models.IntegerField(default=0)
    likes = models.IntegerField(default=0)
    unlikes = models.IntegerField(default=0)
    price_in_euros = models.DecimalField(max_digits=6,
                                         decimal_places=2,
                                         validators=[MinValueValidator(0)],)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def price_in_btc(self):
        c = Currency.objects.get(name="euro")
        return round(((float(self.price_in_euros)) / c.btc_to_currency), 5)

    def save(self, *args, **kwargs):
        if has_changed(self, 'photo'):
            # on va convertir l'image en jpg
            f, e = os.path.splitext(str(self.photo.name))
            filename = "{}.jpg".format(f)

            # Ne fait rien si pas d'image
            try:
                image = Image.open(self.photo.file)

                if image.mode not in ('L', 'RGB'):
                    image = image.convert('RGB')

                # pré-sauvegarde de la photo modifié
                self.photo.save(
                    filename,
                    create_thumb(image, (600, 400)),
                    save=False
                )
            except ValueError:
                pass

        super(Product, self).save(*args, **kwargs)

    def __str__(self):
        return self.name


class Currency(models.Model):
    name = models.CharField(max_length=300, unique=True, default="euro")
    btc_to_currency = models.FloatField(default=252.8)
    currency_to_btc = models.FloatField(default=0.003955696202531645)

    def __str__(self):
        return self.name


class Publicity(models.Model):
    name = models.CharField(max_length=300, default="Publicité")
    shop = models.ForeignKey(Shop, blank=True, null=True)
    user = models.ForeignKey(User, blank=True, null=True)
    url = models.URLField(default='', max_length=100, blank=True)
    description = models.TextField(default='', blank=True)
    image = models.ImageField(upload_to='pub_images',
                              blank=True)
    due_date = models.DateField(default=date.today)
    end_date = models.DateField(default=date.today)
    active = models.BooleanField(default=True)
    note = models.TextField(default='', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if has_changed(self, 'image'):
            # on va convertir l'image en jpg
            f, e = os.path.splitext(str(self.image.name))
            filename = "{}.jpg".format(f)

            # Ne fait rien si pas d'image
            try:
                im = Image.open(self.image.file)

                if im.mode not in ('L', 'RGB'):
                    im = im.convert('RGB')

                # pré-sauvegarde de la photo modifié
                self.image.save(
                    filename,
                    create_thumb(im, (1300, 300)),
                    save=False
                )
            except ValueError:
                pass

        super(Publicity, self).save(*args, **kwargs)

    def __str__(self):
        return str(self.name)
