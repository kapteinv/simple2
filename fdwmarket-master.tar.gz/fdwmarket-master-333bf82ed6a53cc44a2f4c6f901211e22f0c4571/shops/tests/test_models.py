from django.test import TestCase
from django.core.exceptions import ValidationError
from shops.models import Product, Shop


# class ShopAndProductModelTest(TestCase):
#
#     def test_saving_and_retrieving_product(self):
#         shop_ = Shop()
#         shop_.save()
#
#         first_product = Product()
#         first_product.name = 'The first (ever) product to sell'
#         first_product.shop = shop_
#         first_product.save()
#
#         second_product = Product()
#         second_product.name = 'The second product to sell'
#         second_product.shop = shop_
#         second_product.save()
#
#         saved_shop = Shop.objects.first()
#         self.assertEqual(saved_shop, shop_)
#
#         saved_products = Product.objects.all()
#         self.assertEqual(saved_products.count(), 2)
#
#         first_saved_product = saved_products[0]
#         second_saved_product = saved_products[1]
#         self.assertEqual(
#             first_saved_product.name,
#             'The first (ever) product to sell'
#             )
#         self.assertEqual(first_saved_product.shop, shop_)
#         self.assertEqual(
#             second_saved_product.name, 'The second product to sell'
#             )
#         self.assertEqual(second_saved_product.shop, shop_)
#
#     def test_cannot_save_empty_product(self):
#         shop_ = Shop.objects.create()
#         product = Product(shop=shop_, name='')
#         with self.assertRaises(ValidationError):
#             product.save()
#             product.full_clean()
#
#     def test_get_absolute_url(self):
#         shop_ = Shop.objects.create()
#         self.assertEqual(shop_.get_absolute_url(), '/shops/%d/' % (shop_.id,))
