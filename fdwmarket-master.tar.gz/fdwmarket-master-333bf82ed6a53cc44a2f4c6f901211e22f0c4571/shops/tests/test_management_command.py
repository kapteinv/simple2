import datetime
from django.test import TestCase
from django.core.management import call_command
from django.utils import timezone
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.models import User
from postman.models import Message
from account.models import Account
from shops.models import Currency, Category, Shop, Product
import requests


class UpdatecurrencyTestCase(TestCase):

    def test_updatecurrency_update_model_or_create_it_if_dont_exist(self):
        url = "https://apiv2.bitcoinaverage.com/indices/global/ticker/BTCEUR"
        # test create the model if not exist
        r = requests.get(url)
        btc_rate = round(r.json()['last'], 2)
        call_command('updatecurrency')
        self.assertEqual(
            Currency.objects.get(name="euro").btc_to_currency, btc_rate
        )
        # test update the model if exist
        r = requests.get(url)
        btc_rate2 = round(r.json()['last'], 2)
        call_command('updatecurrency')
        self.assertEqual(
            Currency.objects.get(name="euro").btc_to_currency, btc_rate2
       )


class DeleteMessagesTestCase(TestCase):
    """
    Test message deletion.

    Test that message older than 60 days are all deleted.
    Test that message deleted on the 2 sides older than 30 days are deleted.
    """

    def setUp(self):
        # create PM old of 60 days and not deleted by sender or recipient
        # Must be deleted
        Message.objects.create(
            subject="not_deleted_by_s_and_r_since_60",
            sent_at=timezone.now() - datetime.timedelta(days=60)
            )

        # create PM old of 60 days and deleted by sender since 20 days
        # Must be deleted
        Message.objects.create(
            subject="deleted_by_s_since_20",
            sent_at=timezone.now() - datetime.timedelta(days=60),
            sender_deleted_at=timezone.now() - datetime.timedelta(days=20)
            )

        # create PM old of 60 days and deleted by recipient since 20 days
        # Must be deleted
        Message.objects.create(
            subject="deleted_by_r_since_20",
            sent_at=timezone.now() - datetime.timedelta(days=60),
            recipient_deleted_at=timezone.now() - datetime.timedelta(days=20)
            )

        # create PM old of 40 days and not deleted by sender or recipient
        # Don't delete
        Message.objects.create(
            subject="not_deleted_by_s_and_r_since_40",
            sent_at=timezone.now() - datetime.timedelta(days=40)
            )

        # create PM old of 40 days and deleted by sender at 20
        # Don't delete
        Message.objects.create(
            subject="deleted_by_s_since_20",
            sent_at=timezone.now() - datetime.timedelta(days=40),
            sender_deleted_at=timezone.now() - datetime.timedelta(days=20)
            )
        # create PM old of 40 days and deleted by recipient at 20
        # Don't delete
        Message.objects.create(
            subject="deleted_by_r_since_20",
            sent_at=timezone.now() - datetime.timedelta(days=40),
            recipient_deleted_at=timezone.now() - datetime.timedelta(days=20)
            )

    def test_not_deleted_by_sender_and_recipient_since_60_days_is_deleted(self):
        call_command('delete_deleted_messages', 30, 60)
        with self.assertRaises(ObjectDoesNotExist):
            Message.objects.get(subject="not_deleted_by_s_and_r_since_60")

    def test_60_days_message_deleted_by_recipient_since_30_is_deleted(self):
        call_command('delete_deleted_messages', 30, 60)
        with self.assertRaises(ObjectDoesNotExist):
            Message.objects.get(subject="deleted_by_r_since_30")

    def test_40_old_days_message_not_deleted_by_sender_or_recipient_is_keeped(self):
        call_command('delete_deleted_messages', 30, 60)
        Message.objects.get(subject="not_deleted_by_s_and_r_since_40")

    def test_40_old_days_message_deleted_by_sender_at_20_is_keeped(self):
        call_command('delete_deleted_messages', 30, 60)
        Message.objects.get(subject="deleted_by_s_since_20")

    def test_40_old_days_message_deleted_by_recipient_at_20_is_keeped(self):
        call_command('delete_deleted_messages', 30, 60)
        Message.objects.get(subject="deleted_by_r_since_20")


class CleanOldUserTestCase(TestCase):
    """
    Test disactivate inactive users.

    Test that user who did not log-in since 90 days is disactived.
    Test that user Who never log-in 90 days after account creation is
    disactived.
    """

    def setUp(self):

        self.notlogin_msg = """
                    Compte désactivé pour inactivité.
                    Cet utilisateur ne s'est plus connecté depuis plus de 90 jours.
                    """
        self.neverlogin_msg = """
                    Compte désactivé pour inactivité
                    Plus de 90 jours après la création du compte cet utilisateur ne s'est jamais connecté
                    """

        # create one category
        cat = Category.objects.create(name="test")

        #
        # Create buyer created now
        u1 = User.objects.create(username="newbuyer")
        Account.objects.create(user=u1)

        # Create buyer not log-in since 90 days
        u = User.objects.create(username="notloginbuyer")
        Account.objects.create(user=u)
        u.last_login = timezone.now() - datetime.timedelta(days=90)
        u.save()


        # Create buyer never log-in and created since 90 days.
        u = User.objects.create(username="neverloginbuyer")
        Account.objects.create(user=u)
        u.date_joined = timezone.now() - datetime.timedelta(days=90)
        u.is_active = False
        u.save()

        #
        # Create vendor created now with shop, prod & feed
        u = User.objects.create(username="newvendor")
        Account.objects.create(user=u)
        Shop.objects.create(name=u)
        Product.objects.create(
            name="test", price_in_euros=10, category=cat, shop=u
        )

        # Create vendor not log-in since 90 days
        u = User.objects.create(username="notloginvendor")
        Account.objects.create(user=u)
        u.last_login = timezone.now() - datetime.timedelta(days=90)
        Shop.objects.create(name=u)
        Product.objects.create(
            name="test", price_in_euros=10, category=cat, shop=u
        )
        u.save()

        # Create user not log-in since 90 days and banned
        u = User.objects.create(username="notloginbanned")
        Account.objects.create(user=u)
        u.account.banned = True
        u.account.save()
        u.last_login = timezone.now() - datetime.timedelta(days=90)
        u.is_active = False
        u.save()

    def test_new_created_user_not_deactivate(self):
        call_command('clean_olduser', 90, 90)
        u = User.objects.get(username="newbuyer")
        self.assertTrue(u.is_active)
        self.assertEqual(u.account.admin_msg, "")
        self.assertFalse(u.account.inactive)

    def test_user_not_login_since_90_days_is_deactivate(self):
        call_command('clean_olduser', 90, 90)
        u = User.objects.get(username="notloginbuyer")
        self.assertFalse(u.is_active)
        self.assertEqual(u.account.admin_msg, self.notlogin_msg)
        self.assertTrue(u.account.inactive)


    def test_user_never_login_since_90_days_is_deactivate(self):
        call_command('clean_olduser', 90, 90)
        u = User.objects.get(username="neverloginbuyer")
        self.assertFalse(u.is_active)
        self.assertEqual(u.account.admin_msg, self.neverlogin_msg)
        self.assertTrue(u.account.inactive)

    def test_new_vendor_is_not_deactivate(self):
        call_command('clean_olduser', 90, 90)
        u = User.objects.get(username="newvendor")
        self.assertTrue(u.is_active)
        self.assertEqual(u.account.admin_msg, "")
        Shop.objects.get(name=u)
        self.assertEquals(Product.objects.filter(shop=u).count(), 1)
        self.assertFalse(u.account.inactive)

    def test_not_login_vendor_since_90_days_is_deactivate(self):
        call_command('clean_olduser', 90, 90)
        u = User.objects.get(username="notloginvendor")
        self.assertFalse(u.is_active)
        self.assertEqual(u.account.admin_msg, self.notlogin_msg)
        with self.assertRaises(ObjectDoesNotExist):
            Shop.objects.get(name=u)
        with self.assertRaises(ObjectDoesNotExist):
            Product.objects.get(shop=u)
        self.assertTrue(u.account.inactive)

    def test_do_nothing_if_user_not_login_since_90_days_and_banned(self):
        call_command('clean_olduser', 90, 90)
        u = User.objects.get(username="notloginbanned")
        self.assertEqual(u.account.admin_msg, '')
        self.assertFalse(u.account.inactive)
