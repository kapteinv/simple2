from django.test import TestCase
from django.utils.html import escape

from shops.models import Product, Shop
from shops.forms import ProductForm, EMPTY_PRODUCT_NAME_ERROR


class HomePageTest(TestCase):

    def test_home_page_renders_home_template(self):
        response = self.client.get('/')
        self.assertTemplateUsed(response, 'shops/home.html')

#     def test_home_page_uses_product_form(self):
#         response = self.client.get('/')
#         self.assertIsInstance(response.context['form'], ProductForm)
#
#
# class NewShopTest(TestCase):
#
#     def test_saving_a_POST_request(self):
#         self.client.post(
#             '/shops/new',
#             data={'name': 'A new shop product'}
#             )
#         self.assertEqual(Product.objects.count(), 1)
#         new_product = Product.objects.first()
#         self.assertEqual(new_product.name, 'A new shop product')
#
#     def test_redirects_after_POST(self):
#         response = self.client.post(
#             '/shops/new',
#             data={'name': 'A new shop product'}
#             )
#         new_shop = Shop.objects.first()
#         self.assertRedirects(response, '/shops/%d/' % (new_shop.id,))
#
#     def test_for_invalid_input_renders_home_template(self):
#         response = self.client.post('/shops/new', data={'name': ''})
#         self.assertEqual(response.status_code, 200)
#         self.assertTemplateUsed(response, 'home.html')
#
#     def test_validation_errors_are_shown_on_home_page(self):
#         response = self.client.post('/shops/new', data={'name': ''})
#         self.assertContains(response, escape(EMPTY_PRODUCT_NAME_ERROR))
#
#     def test_for_invalid_input_passes_form_to_template(self):
#         response = self.client.post('/shops/new', data={'name': ''})
#         self.assertIsInstance(response.context['form'], ProductForm)
#
#     def test_invalid_shop_product_names_arent_saved(self):
#         self.client.post('/shops/new', data={'name': ''})
#         self.assertEqual(Shop.objects.count(), 0)
#         self.assertEqual(Shop.objects.count(), 0)
#
#
# class ShopViewTest(TestCase):
#
#     def test_uses_shop_template(self):
#         shop_ = Shop.objects.create()
#         response = self.client.get('/shops/%d/' % (shop_.id))
#         self.assertTemplateUsed(response, 'shop.html')
#
#     def test_passes_correct_shop_to_template(self):
#         other_shop = Shop.objects.create()
#         correct_shop = Shop.objects.create()
#         response = self.client.get('/shops/%d/' % (correct_shop.id,))
#         self.assertEqual(response.context['shop'], correct_shop)
#
#     def test_displays_product_form(self):
#         shop_ = Shop.objects.create()
#         response = self.client.get('/shops/%d/' % (shop_.id,))
#         self.assertIsInstance(response.context['form'], ProductForm)
#         self.assertContains(response, 'name="name"')
#
#     def test_display_only_products_for_that_shop(self):
#         correct_shop = Shop.objects.create()
#         Product.objects.create(name='prod 1', shop=correct_shop)
#         Product.objects.create(name='prod 2', shop=correct_shop)
#         other_shop = Shop.objects.create()
#         Product.objects.create(name='other shop prod 1', shop=other_shop)
#         Product.objects.create(name='other shop prod 2', shop=other_shop)
#
#         response = self.client.get('/shops/%d/' % (correct_shop.id,))
#
#         self.assertContains(response, 'prod 1')
#         self.assertContains(response, 'prod 2')
#         self.assertNotContains(response, 'other shop prod 1')
#         self.assertNotContains(response, 'other shop prod 2')
#
#     def test_can_save_a_POST_request_to_an_existing_shop(self):
#         other_shop = Shop.objects.create()
#         correct_shop = Shop.objects.create()
#
#         self.client.post(
#             '/shops/%d/' % (correct_shop.id,),
#             data={'name': 'A new product for an existing shop'}
#             )
#
#         self.assertEqual(Product.objects.count(), 1)
#         new_product = Product.objects.first()
#         self.assertEqual(
#             new_product.name, 'A new product for an existing shop'
#             )
#         self.assertEqual(new_product.shop, correct_shop)
#
#     def test_POST_redirects_to_shop_view(self):
#         other_shop = Shop.objects.create()
#         correct_shop = Shop.objects.create()
#
#         response = self.client.post(
#             '/shops/%d/' % (correct_shop.id,),
#             data={'name': 'A new product for an existing shop'}
#         )
#         self.assertRedirects(response, '/shops/%d/' % (correct_shop.id,))
#
#     def post_invalid_input(self):
#         shop_ = Shop.objects.create()
#         return self.client.post(
#             '/shops/%d/' % (shop_.id,), data={'name': ''}
#         )
#
#     def test_for_invalid_input_nothing_saved_to_db(self):
#         self.post_invalid_input()
#         self.assertEqual(Product.objects.count(), 0)
#
#     def test_for_invalid_input_renders_to_template(self):
#         response = self.post_invalid_input()
#         self.assertEqual(response.status_code, 200)
#         self.assertTemplateUsed(response, 'shop.html')
#
#     def test_for_invalid_input_passes_form_to_template(self):
#         response = self.post_invalid_input()
#         self.assertIsInstance(response.context['form'], ProductForm)
#
#     def test_for_invalid_input_shows_error_on_page(self):
#         response = self.post_invalid_input()
#         self.assertContains(response, escape(EMPTY_PRODUCT_NAME_ERROR))
