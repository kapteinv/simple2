# from django.test import TestCase
#
# from .models import Shop, Product
# from .forms import EMPTY_PRODUCT_NAME_ERROR, ProductForm
#
#
# class ProductFormTest(TestCase):
#
#     def test_form_input_has_placeholder_and_css_classes(self):
#         form = ProductForm()
#         self.assertIn('placeholder="A new product name"', form.as_p())
#         self.assertIn('class="form-control input-lg"', form.as_p())
#
#     def test_form_validation_for_blank_product_names(self):
#         form = ProductForm(data={'name': ''})
#         self.assertFalse(form.is_valid())
#         self.assertEqual(
#                 form.errors['name'],
#                 [EMPTY_PRODUCT_NAME_ERROR]
#         )
#
#     def test_form_save_handles_saving_to_a_shop(self):
#         shop_ = Shop.objects.create()
#         form = ProductForm(data={'name': 'objet cool'})
#         new_product = form.save(for_shop=shop_)
#         self.assertEqual(new_product, Product.objects.first())
#         self.assertEqual(new_product.name, 'objet cool')
#         self.assertEqual(new_product.shop, shop_)
