import sys

from django.core.exceptions import ObjectDoesNotExist

from .models import Currency, Publicity

if sys.version_info < (3, 6):
    ModuleNotFoundError = ImportError
try:
    from fdwmarket.settings.prod import PUB_CONTACT, PUB_PRICE
except ModuleNotFoundError:
    from fdwmarket.settings.test import PUB_CONTACT, PUB_PRICE



def btc_rate(request):
    try:
        c = Currency.objects.get(name='euro')
        return {'btc_rate': c.btc_to_currency}
    except ObjectDoesNotExist:
        return {'btc_rate': 0}


def pub_list(request):
    pub_list = Publicity.objects.filter(active=True).order_by("?")
    return {'pub_list': pub_list}


def pub_contact(request):
    return {'pub_contact': PUB_CONTACT}

def pub_price(request):
    return {'pub_price': PUB_PRICE}
