import sys

from django import template
from django.core.files.storage import default_storage


if sys.version_info < (3, 6):
    ModuleNotFoundError = ImportError
try:
    from fdwmarket.settings.prod import MEDIA_ROOT, MEDIA_URL
except ModuleNotFoundError:
    from fdwmarket.settings.test import MEDIA_ROOT, MEDIA_URL

register = template.Library()


@register.filter(name='picture_exists')
def picture_exists(filepath):
    if default_storage.exists("{}/{}".format(MEDIA_ROOT, filepath)):
        return "{}/{}".format(MEDIA_URL, filepath)
    else:
        return "{}/pub_images/default.jpg".format(MEDIA_URL)
