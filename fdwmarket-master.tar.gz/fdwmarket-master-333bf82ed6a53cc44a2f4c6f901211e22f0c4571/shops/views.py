# -*- coding: utf-8 -*-
from django.contrib.auth.models import User
from django.db.models import Q
from django.views.generic import TemplateView, ListView, DetailView, CreateView
from django.views.generic import UpdateView, DeleteView
from django.views.generic.detail import SingleObjectMixin
from shops.models import Shop, Category, Product, sorted
from django.contrib.auth.decorators import permission_required
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.core.urlresolvers import reverse_lazy
from django.core.exceptions import ObjectDoesNotExist
# pagination:
from django.core.paginator import Paginator
from django.core.paginator import EmptyPage
from django.core.paginator import PageNotAnInteger


class AboutView(TemplateView):
    template_name = "shops/about.html"

    def get_context_data(self, **kwargs):
        context = super(AboutView, self).get_context_data(**kwargs)
        context['totalusers'] = User.objects.filter(is_active=True).count()
        context['buyers'] = (
            User.objects.filter(groups__name='buyer', is_active=True)
        )
        context['totalbuyers'] = (
            User.objects.filter(groups__name='buyer', is_active=True).count()
        )
        context['vendors'] = (
            User.objects.filter(groups__name='vendor', is_active=True)
        )
        context['totalvendors'] = (
            User.objects.filter(groups__name='vendor', is_active=True).count()
        )
        context['modos'] = (
            User.objects.filter(groups__name='modo', is_active=True)
        )
        context['totalmodos'] = (
            User.objects.filter(groups__name='modo', is_active=True).count()
        )
        context['escrows'] = (
            User.objects.filter(groups__name='escrow', is_active=True)
        )
        context['totalescrows'] = (
            User.objects.filter(groups__name='escrow', is_active=True).count()
        )
        return context


class UserListView(ListView):
    model = User
    template_name = "shops/users_list.html"

    def get_context_data(self, **kwargs):
        context = super(UserListView, self).get_context_data(**kwargs)
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(UserListView, self).dispatch(*args, **kwargs)


class RulesView(TemplateView):
    template_name = "shops/rules.html"


class ContactView(TemplateView):
    template_name = "shops/contact.html"


class HomePageView(ListView):
    model = Product
    template_name = "shops/home.html"
    context_object_name = "products"
    order = '-photo'
    paginate_by = 21
    allow_empty = True

    def get_context_data(self, **kwargs):
        context = super(HomePageView, self).get_context_data(**kwargs)
        context['categories'] = sorted(Category.objects.order_by('name'))
        query = self.request.GET.get('search')
        if query:
            context['query'] = query
        return context

    def get_queryset(self):
        order = self.kwargs['order']
        qs = super(HomePageView, self).get_queryset().order_by(order, '-photo')
        query = self.request.GET.get('search')
        if query:
            qs = Product.objects.filter(
               Q(name__icontains=query) | Q(description__icontains=query)
            ).distinct().order_by('-photo')
        return qs


class CategoryList(ListView):
    model = Category
    template_name = "shops/category_list.html"

    def get_context_data(self, **kwargs):
        context = super(CategoryList, self).get_context_data(**kwargs)
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(CategoryList, self).dispatch(*args, **kwargs)


class CategoryDetail(DetailView):

    model = Category
    template_name = "shops/category_detail.html"

    def get_context_data(self, **kwargs):
        context = super(CategoryDetail, self).get_context_data(**kwargs)
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(CategoryDetail, self).dispatch(*args, **kwargs)


class ProductList(ListView):
    model = Product
    template_name = "shops/products.html"
    paginate_by = 21

    def get_context_data(self, **kwargs):
        context = super(ProductList, self).get_context_data(**kwargs)
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ProductList, self).dispatch(*args, **kwargs)


class ProductDetailView(DetailView):

    model = Product

    def get_context_data(self, **kwargs):
        context = super(ProductDetailView, self).get_context_data(**kwargs)
        context['products'] = Product.objects.order_by('name')
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ProductDetailView, self).dispatch(*args, **kwargs)


class AddShopView(CreateView):
    model = Shop
    fields = [
        'enseigne', 'escrow_accepted', 'description', 'accepted_currencies'
    ]
    template_name = 'shops/add_shop.html'

    def form_valid(self, form):
        form.instance.name = self.request.user
        return super(AddShopView, self).form_valid(form)

    def get_success_url(self):
        return '/'

    @method_decorator(permission_required('shops.add_shop'))
    def dispatch(self, *args, **kwargs):
        return super(AddShopView, self).dispatch(*args, **kwargs)


class ShopList(ListView):
    model = Shop
    template_name = "shops/shops_list.html"
    paginate_by = 21

    def get_context_data(self, **kwargs):
        context = super(ShopList, self).get_context_data(**kwargs)
        order = self.kwargs['order']
        list_shop = Shop.objects.order_by(order)
        paginator = Paginator(list_shop, self.paginate_by)
        page = self.request.GET.get('page')

        try:
            shops = paginator.page(page)
        except PageNotAnInteger:
            shops = paginator.page(1)
        except EmptyPage:
            shops = paginator.page(paginator.num_pages)

        context['shops'] = shops
        context['categories'] = sorted(Category.objects.order_by('name'))
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ShopList, self).dispatch(*args, **kwargs)


class ShopDetailView(SingleObjectMixin, ListView): 
    template_name = 'shops/shop_detail.html'
    paginate_by = 21

    def get(self, request, *args, **kwargs):
        self.object = self.get_object(queryset=Shop.objects.all())
        return super(ShopDetailView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(ShopDetailView, self).get_context_data(**kwargs)
        context['shop'] = self.object
        return context

    def get_queryset(self):
        return Product.objects.filter(shop__username=self.object) 


    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ShopDetailView, self).dispatch(*args, **kwargs)


class ShopUpdate(UpdateView):
    model = Shop
    fields = [
        'enseigne', 'escrow_accepted', 'description', 'accepted_currencies'
    ]
    template_name = 'shops/modify_shop.html'
    success_url = reverse_lazy('home')

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ShopUpdate, self).dispatch(*args, **kwargs)


class AddCategoryView(CreateView):
    model = Category
    fields = ['parent', 'name']
    template_name = 'shops/add_category.html'

    def form_valid(self, form):
        return super(AddCategoryView, self).form_valid(form)

    def get_success_url(self):
        return '/'

    @method_decorator(permission_required('shops.add_category'))
    def dispatch(self, *args, **kwargs):
        return super(AddCategoryView, self).dispatch(*args, **kwargs)


class AddProductView(CreateView):
    model = Product
    fields = ['name', 'category', 'photo', 'description', 'price_in_euros']
    template_name = 'shops/add_product.html'

    def form_valid(self, form):
        try:
            self.request.user.shop
        except ObjectDoesNotExist:
            Shop(name=self.request.user).save()
        form.instance.shop = self.request.user
        return super(AddProductView, self).form_valid(form)

    def get_success_url(self):
        return '/'

    @method_decorator(permission_required('shops.add_product'))
    def dispatch(self, *args, **kwargs):
        return super(AddProductView, self).dispatch(*args, **kwargs)


class ProductUpdate(UpdateView):
    model = Product
    fields = ['name', 'category', 'photo', 'description', 'price_in_euros']
    template_name = 'shops/modify_product.html'
    success_url = reverse_lazy('home')

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ProductUpdate, self).dispatch(*args, **kwargs)


class ProductDelete(DeleteView):
    model = Product
    template_name = 'shops/delete_product.html'
    success_url = reverse_lazy('home')

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(ProductDelete, self).dispatch(*args, **kwargs)


class EscrowView(ListView):
    model = User
    template_name = "shops/escrow.html"
    paginate_by = 10

    def get_context_data(self, **kwargs):
        context = super(EscrowView, self).get_context_data(**kwargs)
        order = self.kwargs['order']
        list_customusers = User.objects.filter(
            groups__name='escrow'
        ).order_by(order)
        paginator = Paginator(list_customusers, self.paginate_by)
        page = self.request.GET.get('page')

        try:
            customusers = paginator.page(page)
        except PageNotAnInteger:
            customusers = paginator.page(1)
        except EmptyPage:
            customusers = paginator.page(paginator.num_pages)

        context['customusers'] = customusers
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(EscrowView, self).dispatch(*args, **kwargs)
