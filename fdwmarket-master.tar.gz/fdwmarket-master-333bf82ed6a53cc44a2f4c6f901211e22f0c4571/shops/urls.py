from django.conf.urls import url

from .views import ProductList, ProductDetailView, AddProductView
from .views import ShopList, ShopDetailView, AddShopView, ShopUpdate
from .views import ProductUpdate, ProductDelete
from .views import AddCategoryView, CategoryList, CategoryDetail

urlpatterns = [
    url(r'^add_shop/$', AddShopView.as_view(), name="add_shop"),
    url(r'^add_category/$', AddCategoryView.as_view(), name="add_category"),
    url(r'^add_product/$', AddProductView.as_view(), name="add_product"),
    url(r'^shops/category/$', CategoryList.as_view(), name="category"),
    url(
        r'^shops/category/(?P<slug>[-_\w]+)/$', CategoryDetail.as_view(),
        name="categorydetail"
    ),
    url(r'^products/$', ProductList.as_view(), name="products"),
    url(
        r'^products/modify/(?P<slug>[-_\w]+)/$',
        ProductUpdate.as_view(),
        name='modify_prod'
    ),
    url(
        r'^products/delete/(?P<slug>[-_\w]+)/$',
        ProductDelete.as_view(),
        name='delete_prod'
    ),
    url(r'^(?P<slug>[-_\w]+)/$', ShopDetailView.as_view(), name='shop_detail'),
    url(
        r'^product/(?P<slug>[-_\w]+)/$',
        ProductDetailView.as_view(),
        name='product_detail'
    ),
    url(r'^$', ShopList.as_view(), {'order': '?'}, name='shops_list'),
    url(
        r'^order_by/(?P<order>[\w-]+)/$',
        ShopList.as_view(),
        name='shops_order_by'
    ),
    url(
        r'^modify/(?P<slug>[-_\w]+)/$',
        ShopUpdate.as_view(),
        name="modify_shop"
    ),
]
