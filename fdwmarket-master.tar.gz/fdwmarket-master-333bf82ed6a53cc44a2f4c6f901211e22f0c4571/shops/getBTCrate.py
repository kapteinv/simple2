import requests


class GetBtc:
    """
    Module GetBTC to get rate from api like bitcoinaverage.

    Usage :
    =====
    # init the class with the url of the api we want to use,
    # example with bitcoinaverage API for change in euro
    a = GetBtc("https://apiv2.bitcoinaverage.com/indices/global/ticker/BTCEUR")
    # get the rate from bitcoinaverage
    a.exchange()
    # convert 5 euro in btc
    a.to_btc(5)
    # convert 5 btc in euro
    a.to_currency(5)
    # write the rate in a file
    a.to_file(/path/to/file)
    """

    def __init__(self, url):
        self.url = url

    def exchange(self):
        """Get the exchange rate."""
        requete = requests.get(self.url)
        taux = float(requete.json()['last'])
        return round(taux, 2)

    def to_btc(self, value):
        """Convert fiat to btc."""
        currencytobtc = float(value) / self.exchange()
        return round(currencytobtc, 8)

    def to_currency(self, value):
        """convert btc to fiat."""
        btctocurrency = float(value) * self.exchange()
        return round(btctocurrency, 2)

    def to_file(self, filetowrite):
        """Write the exchange rate on a file."""
        with open(filetowrite, "w") as f:
            f.write(str(self.exchange()))


if __name__ == "__main__":

    try:
        input = raw_input
    except NameError:
        pass
    f = input("Enter the file path to write")
    print("Convertisseur Euro/BTC")
    print("######################")
    change = GetBtc("https://apiv2.bitcoinaverage.com/indices/global/ticker/BTCEUR")
    print("change from api :", change.exchange())
    print("1 btc =", change.to_currency(1), "euro")
    print("1 euro =", change.to_btc(1), "btc")
    change.to_file(f)
