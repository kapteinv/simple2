# fdwmarket

Market dédié à la communauté Tor Francophone

FDW-Market est un marketplace, c'est à dire un market permettant a differents vendeurs de vendre leurs produits.
Le market est développé pour la communauté francophone du forum FDW mais devrait être utilisable facilement par n'importe qui.

Ce market a été originellement inspiré de BitWasp mais est entièrement recodé from scratch en python/django en essayant de suivre les principes du tutoriels [django-effective](http://effectivedjango.com "django effective"), c'est à dire que le code doit être cohérent, testable et facile à faire évoluer.
cohérent, c'est à dire que chaque fonction ou methode doit faire une seule chose et le faire bien, un code qui respecte ce principe et facile à tester et un code facile à tester est facile à maintenir et à faire évoluer.

Aucun merge request ne sera accepté si il n'est pas bien documenté ou facile à lire et comprendre (les tests pourront être inclus plus tard), nous voulons produire du code de qualité facile à maintenir.
Voici une liste non exaustive de docs pour ceux voulant participer au développement du projet

* https://docs.djangoproject.com/fr/
* http://effectivedjango.com/index.html
* http://www.tangowithdjango.com/
* http://chimera.labs.oreilly.com
* http://django-by-errors.readthedocs.org/en/latest/
* http://www.formation-django.fr/framework-django/testing/test-controleurs-views.html
* https://godjango.com/17-class-based-views-part-3-detailview-and-template_name-shortcut/
* http://ccbv.co.uk/

Le premier lien est celui de la doc officielle, pour ceux ne connaissant pas ou peu django, commencez par suivre le tutoriel d'initiation. Celui ci et un peu de lecture sur les vues fondées sur les classes devraient suffire pour commencer à vous lancer dans le projet. Il est bien entendu indispensable d'avoir des bases en python.

## Versionning

Depuis la mise en ligne de la v1.0.0 il a été décidé d'essayer de suivre plus ou moins une version simplifiée de la [Gestion sémantique de version 2.0.0](http://semver.org/lang/fr/)

soit vX.Y.Z ou
 * X correspond à un changement majeur ayant surement introduit une retro-incompatibilitée et cassé l'API
 * Y Correspond à un changement important ou ajout d'une fonctionnalité ayant peut être introduit une retro-incompatibilité et cassé l'API
 * Z correspond à un changement mineur ou correctif n'introduisant pas de retro-incompatibilité et ne modifiant pas l'API

## Installation

> /!\ Tutoriel d'installation pour le développement, ne surtout pas utiliser en production

seule la compatibilité avec python3.5.3 et + est garantie.
l'installation a été testée avec succes sur :
 * ubuntu 16.04
 * Debian Jessie
 * raspberry pi 3 avec raspbian
 * android rooté avec chroot debian (exemple nethunter)
 * android (root optionnel) avec termux (note d'installation à venir)
 * Windows 10 64-bit - Windows Subsystem for Linux a.k.a. Bash on Ubuntu (14.04 LTS) avec pyenv afin de pouvoir installer Python 3.6 cf. http://askubuntu.com/a/865644

 L'installation sur d'autres OS linux ne devrait pas poser de problème mais le nom des paquets des dependances peuvent être différents.
 L'installation sous mac ne devrait pas etre bien plus compliqué mais n'a encore jamais été testé.


### Installations dépendances (Debian/ubuntu et variantes)


#### Dépendances necessaires à la compilation et au virtualenv:
```bash
# apt-get install python3-dev build-essential python3-venv
```

> **Note:** si l'installation de build-essential est impossible (android termux), l'installation de gcc devrait suffire
```
#termux
apt install python-dev clang
```

#### Dépendances de pillow pour le support de jpeg et png (pour le support de plus de format se réferrer à la doc officielle de pillow)

```bash
# apt-get install libjpeg-dev zlib1g-dev
```

```
# termux
apt-get install libjpeg-turbo-dev
```

### Installation et mise à jour du virtualenv et clonage du dépôt

> **notes :**
>  
> * git doit avoir été installé préalablement (si ce n'est pas le cas : ```apt-get install git```
> * le dépôt étant hébergé sur un hiddden service, il vous faut faire passer git par le proxy socks Tor. Le plus simple est d'utiliser torsocks qui est installé par defaut avec Tor quand celui-ci est installé via les dépôts(```apt-get install torsocks``` si vous ne l'avez pas déjà). En  alternative à torsocks, il est possible d'utiliser socat, mais son utilisation étant plus complexe, elle ne sera pas détaillée ici. Si vous utilisez une config de type transproxy(whonix, tails, orbot sur android rooté), toutes vos requetes sont déjà routées à travers Tor, torsocks est donc inutile.

Les commandes suivantes ne necessitent pas les droits root

#### création et activation du virtualenv:

```bash
$ python3 -m venv env
$ source env/bin/activate
```

Les versions de pip et setuptools installées par défaut dans le virtualenv sont outdatée et wheel est manquant, ce qui peut poser des problèmes lors de l'installation de certains modules python, il faut donc mettre à jour ces modules:

```bash
(env)$ pip install -U pip setuptools wheel
```
On peut maintenant cloner le dépôt:

```bash
$ torsocks git clone http://haklab4ulibiyeix.onion/devmarket/fdwmarket.git
```
On se rend maintenant dans le repertoire fraichement installé et on installe les modules python requis

> #### note sur les modules requis:
 Selenium est necessaire pour les tests fonctionnels (voir le chapitre sur les tests). Si vous ne pouvez pas ou ne voulez pas effectuer ces tests et que vous voulez economiser l'installation de ce module vous pouvez commenter la ligne contenant ```selenium``` dans le fichiers requirements.txt.  
> afin de faciliter le developpement, django debug toolbar est installé par défaut, si vous ne souhaitez pas l'installer vous pouvez commenter les lignes contenant ```django-debug-toolbar``` dans le fichier ```requirements.txt```

> /!\ En raison d'un probleme de compatibilité entre pathlib et django-debug-toolbar, si vous utilisez une version de python inférieure à la 3.6 remlacez settings.local par settings.test dans les commandes suivante.
De même si vous n'avez pas installer django-debug-toolbar.

```bash  
(env)$ cd fdwmarket
(env)$ pip install -r requirements.txt
```

```
#installation pillow sous termux
pip install pillow --global-option="build_ext" --global-option="--disable-zlib" --global-option="--disable-jpeg
```

## preparation de la BDD et installation automatique des données initiales pour le développement

> **Note:**  Si lors de l'installation des données initiales on obtient une erreur de
contentypes, il faut les supprimer depuis le shell django:
```
$ python manage.py shell --settings=fdwmarket.settings.local
>>> from django.contrib.contenttypes.models import ContentType  
>>> ContentType.objects.all().delete()  
>>> quit()                        
```


```bash
(env)$ #création du repertoire de la bdd de développement
(env)$ mkdir ../database
(env) $ python manage.py makemigrations account feedbacks moderation scam_report shops django_messages --settings=fdwmarket.settings.local
(env)# on applique les migrations
(env)$ python manage.py migrate --settings=fdwmarket.settings.local
(env)$ # installation des données initiales
(env)$ python manage.py loaddata -i fixtures/initial.json --settings=fdwmarket.settings.local
(env)$ # demarrage du serveur de developpement
(env)$ python manage.py runserver --settings=fdwmarket.settings.local
```

## reinitialisation de la BDD
Au cours du développement il peut arriver que des erreurs nous oblige à réinitialiser la BDD:
pour ce faire, lancer la commande suivante depuis le répertoire ou se trouve manage.py
```bash
$ rm -r ../database/* account/migrations/* shops/migrations/* feedbacks/migrations/*
```

Vous pouvez alors procéder à nouveau à la préparation de la BDD et à l'installation automatique des données initiales

#### Commande de management updatecurrency
Pour mettre à jour le taux de change btc/eur, utilisez la commande de management updatecurrency:
```bash
(env)$ python manage.py updatecurrency --settings=fdwmarket.settings.local
```

on peut maintenant lancer le serveur de développement:
```bash
(env)$ python manage.py runserver --settings=fdwmarket.settings.local
```


## Contribuer au développement du FDW-Market

Vous pouvez faire un clone du projet et faire des merge requests de vos modifications.
Si vous avez été intégré en tant que membre developeur du projet, vous pouvez aussi travailler directement sur le dépôt du projet, ce qui est la méthode recommandée..
La branche master étant protégée, il ne vous est pas possible d'y pousser vos modifications, même après avoir été ajouté en tant que dévelopeur au projet.
Vous devez créer votre propre branche afin d'eviter des conflits avec d'autres dev :

```bash
git branch <nom_branche>
git checkout <nom_branche>
```
on peut aussi creer et basculer dans la nouvelle branche en une seule ligne de commande:
```bash
git checkout -b <nom_branche>
```
pour pousser votre branche sur le serveur :
```bash
torsocks git push origin <nom_branche>
```

Une fois satisfait de votre travail vous pourrez faire un merge request :
* via la page merge request du gitlab
* en contactant v1ct0r par le moyen de votre choix

## Les tests

### Les tests fonctionnels

Nous utilisons selenium avec le driver geckodriver pour les tests fonctionnels.
Vous devez installer la dernière version de geckodriver correspondant à votre infrastructure depuis le github de mozilla:
https://github.com/mozilla/geckodriver/releases
décompresser l'archive et la rendre disponible dans le system path.

> **Note:**   l'utilisation de la derniere version de geckodriver avec une version de firefox inférieure à
firefox 52 provoque l'erreur suivante:  
> ```Unable to find  a matching set of capabilities```   
> voir (https://github.com/SeleniumHQ/selenium/issues/3884)  


exemple pour un linux x86_64:  
```
$ wget https://github.com/mozilla/geckodriver/releases/download/v0.18.0/geckodriver-v0.18.0-linux64.tar.gz
$ tar xvzf geckodriver-v0.18.0-linux64.tar.gz
$ sudo mv geckodriver /usr/local/bin/
$ rm geckodriver-v0.18.0-linux64.tar.gz
```
Vous pouvez verifiez que geckodriver est correctement installé en lançant la commande:
```geckodriver --version```

#### Lancer les tests fonctionnels

pour executer les tests fonctionnels, placez vous dans votre virtualenv et utilisez la commande suivante:
```(env)$ python manage.py functional_tests --settings=fdwmarket.settings_test```

### Les test unitaires

Les tests unitaires ne sont pas encore disponibles
