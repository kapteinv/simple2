from django.apps import AppConfig


class ModerationConfig(AppConfig):
    name = 'moderation'
