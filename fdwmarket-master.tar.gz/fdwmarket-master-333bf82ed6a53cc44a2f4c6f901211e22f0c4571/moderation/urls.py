from django.conf.urls import url

from .views import ModerateScamReportView, BanUserView

urlpatterns = [
    url(
        r'^scam_report/([\w-]+)/([\w-]+)/$',
        ModerateScamReportView.as_view(),
        name="moderate_scam_report"
        ),
    url(
        r'^ban_user/(?P<slug>[-_\w]+)/$',
        BanUserView.as_view(),
        name='banuser'
        ),
]
