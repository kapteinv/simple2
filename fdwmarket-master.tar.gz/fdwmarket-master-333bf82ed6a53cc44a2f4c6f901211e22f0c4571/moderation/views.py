from postman.models import Message
from django.contrib.auth.models import User, Group
from django.views.generic import ListView, UpdateView
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import permission_required
from django.core.exceptions import ObjectDoesNotExist

from account.models import Account
from shops.models import Shop, Product
from feedbacks.models import UserFeedback


class ModerateScamReportView(ListView):
    template_name = "moderation/moderate_scam_report.html"

    def get_queryset(self):
        self.sender = get_object_or_404(
            User,
            username=self.args[0])
        self.recipient = get_object_or_404(
            User,
            username=self.args[1])
        return Message.objects.filter(
                sender=self.sender, recipient=self.recipient
        ) | Message.objects.filter(
                sender=self.recipient, recipient=self.sender
        ).order_by('sent_at')

    def get_context_data(self, **kwargs):
        context = super(ModerateScamReportView, self).get_context_data(**kwargs)
        context['sender'] = self.sender
        context['recipient'] = self.recipient
        return context

    @method_decorator(permission_required('auth.add_user'))
    def dispatch(self, *args, **kwargs):
        return super(ModerateScamReportView, self).dispatch(*args, **kwargs)


class BanUserView(UpdateView):
    model = Account
    fields = ['admin_msg']
    template_name = 'moderation/ban_user.html'
    success_url = '/'

    def get_initial(self):
        print(self.kwargs)
        return {
            'admin_msg': Account.objects.get(
                slug=self.kwargs['slug']
            ).admin_msg
        }

    def banuser(self, ban_user):
        u = ban_user
        g = Group.objects.get(name="vendor")
        u.is_active = False
        u.account.banned = True
        # u.account.admin_msg = "Scam avéré"
        g.user_set.remove(u)
        try:
            Shop.objects.get(name=u).delete()
            Product.objects.filter(shop=u).delete()
        except ObjectDoesNotExist:
            pass
        u.save()
        u.account.save()
        return "user banni"

    def del_feeds_by(self, ban_user):
        u = ban_user
        UserFeedback.objects.filter(poster=u).delete()
        return "feedbacks postés par utilisateur banni suprimés"

    def form_valid(self, form):
        print(form.instance.user)
        self.banuser(form.instance.user)
        self.del_feeds_by(form.instance.user)
        return super(BanUserView, self).form_valid(form)

    @method_decorator(permission_required('auth.add_user'))
    def dispatch(self, *args, **kwargs):
        return super(BanUserView, self).dispatch(*args, **kwargs)
