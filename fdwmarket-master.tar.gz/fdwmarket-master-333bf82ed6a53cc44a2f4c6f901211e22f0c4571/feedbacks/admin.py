from django.contrib import admin

from .models import UserFeedback, UserFeedbackComment


class UserFeedbackAdmin(admin.ModelAdmin):
    list_display = (
        'title', 'user', 'poster', 'created_at', 'updated_at', 'positive'
    )
    search_fields = ('title', 'user__username', 'poster__username')


class UserFeedbackCommentAdmin(admin.ModelAdmin):
    list_display = (
        'feedback', 'poster', 'created_at', 'updated_at', 'positive', 'text'
    )
    search_fields = ('feedback__title', 'poster__username')


admin.site.register(UserFeedback, UserFeedbackAdmin)
admin.site.register(UserFeedbackComment, UserFeedbackCommentAdmin)
