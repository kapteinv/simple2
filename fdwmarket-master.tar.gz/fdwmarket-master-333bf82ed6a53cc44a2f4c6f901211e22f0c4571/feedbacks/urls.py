from django.conf.urls import url

from .views import AddFeedbackView, FeedbackList, FeedbackDetail
from .views import FeedbackUpdate, FeedbackDelete, AddFeedbackComment
from .views import FeedbackCommentUpdate, FeedbackCommentDelete

urlpatterns = [
    url(
        r'^add_feedback/(?P<slug>[-_\w]+)/$',
        AddFeedbackView.as_view(),
        name="addfeedback"
        ),
    url(
        r'^feedback_list/(?P<slug>[-_\w]+)/$',
        FeedbackList.as_view(),
        name="feedbacklist"
        ),
    url(
        r'^feedback/(?P<pk>[0-9]+)/$',
        FeedbackDetail.as_view(),
        name="feedback"
        ),
    url(
        r'^feedback/modify/(?P<pk>[0-9]+)/$',
        FeedbackUpdate.as_view(),
        name="modifyfeedback"
        ),
    url(r'^feedback/delete/(?P<pk>[0-9]+)/$',
        FeedbackDelete.as_view(),
        name="deletefeedback"
        ),
    url(
        r'^add_feedbackcomment/(?P<pk>[-_\w]+)/$',
        AddFeedbackComment.as_view(),
        name="add_feedbackcomment"
    ),
    url(
        r'^modify/comment/(?P<pk>[0-9]+)/$',
        FeedbackCommentUpdate.as_view(),
        name="modify_feedbackcomment"
        ),
    url(
        r'^delete/comment/(?P<pk>[0-9]+)/$',
        FeedbackCommentDelete.as_view(),
        name="delete_feedbackcomment"
        ),
]
