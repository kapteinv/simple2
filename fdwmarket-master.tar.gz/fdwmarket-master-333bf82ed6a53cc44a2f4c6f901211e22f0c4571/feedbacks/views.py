from django.contrib.auth.models import User
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.views.generic import CreateView, ListView, DetailView, UpdateView
from django.views.generic import DeleteView
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect

from .models import UserFeedback, UserFeedbackComment
from account.models import Account


class AddFeedbackView(CreateView):
    model = UserFeedback
    fields = ['title', 'positive', 'text']
    template_name = 'feedbacks/add_feedback.html'

    def form_valid(self, form):
        form.instance.poster = self.request.user
        form.instance.user = get_object_or_404(
            User,
            account__slug=self.kwargs.get('slug')
        )
        if form.instance.poster == form.instance.user:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)
        else:
            return super(AddFeedbackView, self).form_valid(form)

    def get_context_data(self, **kwargs):
        context = super(AddFeedbackView, self).get_context_data(**kwargs)
        feed_owner = get_object_or_404(
            Account,
            slug=self.kwargs.get('slug')
        )
        context['feed_owner'] = feed_owner
        return context

    def get_success_url(self):
        feed_owner = get_object_or_404(
            Account,
            slug=self.kwargs.get('slug')
        )
        return '/account/{}'.format(feed_owner.slug)

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(AddFeedbackView, self).dispatch(*args, **kwargs)


class FeedbackList(ListView):
    model = UserFeedback
    template_name = "feedbacks/feedback_list.html"

    def get_context_data(self, **kwargs):
        context = super(FeedbackList, self).get_context_data(**kwargs)
        feed_owner = get_object_or_404(
            Account,
            slug=self.kwargs.get('slug')
        )
        context['feed_owner'] = feed_owner.user
        context['feeds'] = feed_owner.user.feedback.all()
        context['totalfeeds'] = feed_owner.user.feedback.all().count()
        context['likes'] = feed_owner.user.feedback.filter(
            positive=True
            ).count()
        context['unlikes'] = feed_owner.user.feedback.filter(
            positive=False
            ).count()
        try:
            context['average'] = round(
                (context['likes'] / context['totalfeeds']) * 100, 2
            )
        except ZeroDivisionError:
            context['average'] = 0
        return context

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(FeedbackList, self).dispatch(*args, **kwargs)


class FeedbackDetail(DetailView):
    model = UserFeedback
    template_name = 'feedbacks/feedback_detail.html'

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(FeedbackDetail, self).dispatch(*args, **kwargs)


class FeedbackUpdate(UpdateView):
    model = UserFeedback
    template_name = 'feedbacks/modify_feedback.html'
    fields = ['title', 'positive', 'text']
    success_url = reverse_lazy('home')

    def form_valid(self, form):
        poster = self.request.user
        if poster == form.instance.poster or poster.has_perm('auth.add_user'):
            return super(FeedbackUpdate, self).form_valid(form)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(FeedbackUpdate, self).dispatch(*args, **kwargs)


class FeedbackDelete(DeleteView):
    model = UserFeedback
    template_name = 'feedbacks/delete_feedback.html'
    success_url = reverse_lazy('home')

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        if self.object.poster == request.user or request.user.has_perm(
            'auth.add_user'
        ):
            self.object.delete()
            success_url = self.get_success_url()
            return HttpResponseRedirect(success_url)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(FeedbackDelete, self).dispatch(*args, **kwargs)


# Commentaires des feedbacks
class AddFeedbackComment(CreateView):
    model = UserFeedbackComment
    fields = ['positive', 'text']
    template_name = 'feedbacks/add_feedbackcomment.html'

    def form_valid(self, form):
        form.instance.poster = self.request.user
        form.instance.feedback = get_object_or_404(
            UserFeedback,
            id=self.kwargs.get('pk')
        )
        return super(AddFeedbackComment, self).form_valid(form)

    def get_success_url(self):
        feedback = get_object_or_404(
            UserFeedback,
            id=self.kwargs.get('pk')
        )
        return '/feedbacks/feedback/{}'.format(feedback.id)

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(AddFeedbackComment, self).dispatch(*args, **kwargs)


class FeedbackCommentUpdate(UpdateView):
    model = UserFeedbackComment
    template_name = 'feedbacks/modify_commentfeedback.html'
    fields = ['positive', 'text']
    success_url = reverse_lazy('home')

    def form_valid(self, form):
        poster = self.request.user
        if poster == form.instance.poster or poster.has_perm('auth.add_user'):
            return super(FeedbackCommentUpdate, self).form_valid(form)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(FeedbackCommentUpdate, self).dispatch(*args, **kwargs)


class FeedbackCommentDelete(DeleteView):
    model = UserFeedbackComment
    template_name = 'feedbacks/delete_commentfeedback.html'
    success_url = reverse_lazy('home')

    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        if self.object.poster == request.user or request.user.has_perm(
            'auth.add_user'
        ):
            self.object.delete()
            success_url = self.get_success_url()
            return HttpResponseRedirect(success_url)
        else:
            return HttpResponse("<h1>Non autorisé</h1>", status=405)

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super(FeedbackCommentDelete, self).dispatch(*args, **kwargs)
