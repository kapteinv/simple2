from django.db import models
from django.contrib.auth.models import User


class UserFeedback(models.Model):

    title = models.CharField(max_length=50)
    user = models.ForeignKey(User, related_name="feedback")
    poster = models.ForeignKey(User)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    positive = models.BooleanField(default=True)
    text = models.TextField(blank=True, default='')

    def __str__(self):
        return str(self.title)


class UserFeedbackComment(models.Model):

    feedback = models.ForeignKey(UserFeedback, blank=True, null=True,
                                 related_name='comments')
    poster = models.ForeignKey(User)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    positive = models.BooleanField(default=True)
    text = models.TextField(blank=True, default='')

    def __str__(self):
        return str(self.feedback)
