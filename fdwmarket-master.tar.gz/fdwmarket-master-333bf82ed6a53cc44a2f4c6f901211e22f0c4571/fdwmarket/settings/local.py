"""
Django settings for fdwmarket project local development.

Extend the settings.base with extra configurations

         -  unsuitable for production -
See https://docs.djangoproject.com/dev/1.9/howto/deployment/checklist/
"""

from .base import *
from .test import MEDIA_ROOT

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'gphpun6!1uli=g)8rua11c7bhpps^zbivkd4wjv!uuy+6u%1gb'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = []

INTERNAL_IPS = ('127.0.0.1',)

INSTALLED_APPS += ['debug_toolbar', ]
MIDDLEWARE += ['debug_toolbar.middleware.DebugToolbarMiddleware', ]


# Database
# https://docs.djangoproject.com/en/dev/ref/settings/#databases
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': str(BASE_DIR / '../database/db.sqlite3'),
    }
}

LOGIN_REDIRECT_URL = '/'
LOGIN_URL = '/login/'
