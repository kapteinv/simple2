from django.conf.urls import include, url
from django.contrib import admin
from django.contrib.auth import views as auth_views
# serving-files-uploaded-by-a-user
from django.conf import settings
from django.conf.urls.static import static

from shops.views import HomePageView, AboutView, ContactView, EscrowView
from shops.views import RulesView, UserListView
from account.views import SignUpView, SignupInfoView, PasswordChangeDoneView


urlpatterns = [
    url(r'^shops/', include('shops.urls')),
    url(r'^feedbacks/', include('feedbacks.urls')),
    url(r'^$', HomePageView.as_view(), {'order': '?'}, name='home'),
    url(
        r'^order_by/(?P<order>[\w-]+)/$',
        HomePageView.as_view(),
        name='home_order_by'
    ),
    url(r'^about/', AboutView.as_view(), name="about"),
    url(r'^contact/', ContactView.as_view(), name='contact'),
    url(r'^rules/', RulesView.as_view(), name='rules'),
    url(r'^account/', include('account.urls')),
    url(r'^escrows/$', EscrowView.as_view(), {'order': '?'}, name='escrows'),
    url(
        r'^escrows/order_by/(?P<order>[\w-]+)/$',
        EscrowView.as_view(),
        name='escrow_order_by'
    ),
    url(r'^users/$', UserListView.as_view(), name='user'),
    url(r'^moderation/', include('moderation.urls')),
    url(r'^scam_report/', include('scam_report.urls')),

    # Identification URLs
    url(r'^login/$', auth_views.login, name='login'),
    url(r'^logout/$', auth_views.logout, {'next_page': '/'}, name='logout'),
    url(r'^signup_info/', SignupInfoView.as_view(), name='signup-info'),
    url(r'^sign_up/', SignUpView.as_view(), name='sign-up'),

    # Change Password URLs:
    url(r'^password_change/$',
        auth_views.password_change,
        {'post_change_redirect': '/password_change/done/'},
        name="password_change"),
    url(r'^password_change/done/$', PasswordChangeDoneView.as_view()),
    # MP
    # url(r'^messages/', include('django_messages.urls')),
    url(r'^messages/', include('postman.urls', namespace='postman', app_name='postman')),
    # Interface Administration
    url(r'^admin/', include(admin.site.urls)),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG:
    import debug_toolbar
    urlpatterns = [
        url(r'^__debug__/', include(debug_toolbar.urls)),
    ] + urlpatterns
