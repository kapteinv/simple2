import time

from django.test import LiveServerTestCase
from django.conf import settings
from django.test import override_settings

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import WebDriverException

from functional_tests.load_data import add_perm_to_group, batch_create_users
from functional_tests.load_data import groups_with_perm, batch_create_vendors
from functional_tests.load_data import batch_create_products

MAX_WAIT = 10


@override_settings(DEBUG=True)
class NewVisitorAtHomeTest(LiveServerTestCase):

    def setUp(self):
        add_perm_to_group(groups_with_perm)
        batch_create_users(groups_with_perm)
        batch_create_vendors()
        batch_create_products("vendor0")

        self.browser = webdriver.Firefox()

    def tearDown(self):
        self.browser.quit()

    def wait_for_link_in_menu(self, link_text):
        start_time = time.time()
        while True:
            try:
                menu = self.browser.find_element_by_class_name('listeflex')
                links = menu.find_elements_by_tag_name('li')
                self.assertIn(link_text, [link.text for link in links])
                return
            except (AssertionError, WebDriverException) as e:
                if time.time() - start_time > MAX_WAIT:
                    raise e
                time.sleep(0.5)

    def test_can_display_home_(self):
        # Alice a entendu parler d'une place de marché cool sur le deepweb,
        # elle décide de se rendre sur sa page d'acceuil
        self.browser.get(self.live_server_url)

        # Elle remarque que le titre et le header mentionne FDW-Market
        self.assertIn('FDW-Market', self.browser.title)
        header_text = self.browser.find_element_by_tag_name('h1').text
        self.assertIn('FDW-Market', header_text)
        # Elle remarque que le site lui indique qu'elle n'est pas connectée en
        # affichant le nom d'utilisateur AnonymousUser dans le menu
        self.browser.find_element_by_link_text('AnonymousUser')
        # Elle remarqie les liens d'identification et d'enregistrement
        self.browser.find_element_by_link_text('Identification')
        self.browser.find_element_by_link_text('Inscription')

    def test_can_display_about(self):
        # Elle remarque le lien about et décide de voir de quoi il s'agit
        response = self.client.get('/about/')
        self.assertTemplateUsed(response, 'shops/about.html')

    def test_can_display_signup_info(self):
        # Elle clique sur Inscription et voit un message d'avertissement
        self.browser.get(self.live_server_url + '/signup_info/')
        self.browser.find_element_by_link_text('CGU')
        self.browser.find_element_by_link_text('Je refuse')
        self.browser.find_element_by_link_text("J'accepte").click()
        # TODO

    def test_can_connect_as_buyer_and_open_scam_report(self):
        # Elle clique sur Identification
        response = self.client.get('/login/')
        self.assertTemplateUsed(response, 'registration/login.html')
        self.browser.get(self.live_server_url + '/login/')
        # elle entre ses identifiants
        input_usernamebox = self.browser.find_element_by_id('id_username')
        input_usernamebox.send_keys('buyer1')
        input_passwordbox = self.browser.find_element_by_id('id_password')
        input_passwordbox.send_keys('buyer1')
        input_passwordbox.send_keys(Keys.ENTER)
        # Elle remarque qu'elle est maintenant connectée en tant que buyer1
        # et que son username est affiché dans le menu
        self.wait_for_link_in_menu('buyer1')
        # elle remarque la liste de produits affichés sur la page home
        # chaque produit comprend un lien pour se rendre sur le shop du vendeur
        # Elle décide de cliquer sur le premier pour acceder au shop du vendeur
        self.browser.find_element_by_link_text("Accéder au shop").click()
        self.wait_for_link_in_menu('buyer1')
        # Elle clique sur le nom du vendeur pour se rendre sur son profil
        self.browser.find_element_by_partial_link_text('vendor').click()
        self.wait_for_link_in_menu('buyer1')
        self.browser.find_element_by_link_text("Ouvrir un scam/report").click()
        # TODO continuer les test

        time.sleep(10)

        # TODO continuer les test
