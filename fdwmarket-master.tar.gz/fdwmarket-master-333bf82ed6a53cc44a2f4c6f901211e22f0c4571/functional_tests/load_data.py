from django.contrib.auth.models import User, Group, Permission
from django.core.exceptions import ObjectDoesNotExist

from account.models import Account
from shops.models import Shop, Product, Category


groups_with_perm = {
    'buyer': ('add_account',),
    'vendor': ('add_product', 'add_shop',),
    'escrow': ('add_account', 'add_user',),
    'modo': (
                'add_account', 'change_account', 'add_user', 'change_user',
                'add_userfeedback', 'change_userfeedback',
                'delete_userfeedback', 'add_userfeedbackcomment',
                'change_userfeedbackcomment', 'delete_userfeedbackcomment',
                'add_category', 'change_category', 'delete_category',
                'add_product', 'change_product', 'delete_product', 'add_shop',
                'change_shop',
        )
    }


def add_perm_to_group(groups_with_perm):
    for group in groups_with_perm:
        g = Group.objects.create(name=group)
        for perm in groups_with_perm[group]:
            p = Permission.objects.get(codename=perm)
            g.permissions.add(p)


def batch_create_users(groups_with_perm):
    for group in groups_with_perm:
        for n in range(0, 11):
            if group == "modo":
                u = User.objects.create_user(
                    username=group + str(n),
                    password=group + str(n),
                    is_staff=True
                    )
            else:
                u = User.objects.create_user(
                    username=group + str(n), password=group + str(n)
                    )
            Account.objects.create(user=u)
            g = Group.objects.get(name=group)
            g.user_set.add(u)


def batch_create_vendors():
    for n in range(0, 11):
        vendor = User.objects.get(username="vendor" + str(n))
        Shop.objects.create(name=vendor)

def batch_create_products(vendorname):
    vendor = User.objects.get(username=vendorname)
    try:
        cat = Category.objects.get(name="test")
    except Category.DoesNotExist:
        cat = Category.objects.create(name="test")
    for n in range(0, 11):
        Product.objects.create(
            shop=vendor, name="prod" + str(n), category=cat, price_in_euros=10
        )
