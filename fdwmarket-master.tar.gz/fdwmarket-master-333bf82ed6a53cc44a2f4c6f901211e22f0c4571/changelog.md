Changelog
=========

version 1.6.1
------------------------
- Update version en 1.6.1. [V1ct0r]
- Ajout d'un validateur, le prix ne peut pas être négatif #53,
  suppression d'un order inutile. [V1ct0r]
- Ajout d'une vue pour mettre à jour le message d'avertissement #279.
  [V1ct0r]

- Merge branch 'lutinmalin' into 'master' [V1ct0r]
- Update README.md (ajout du support de windows 10 dans le Readme). [Lutin]

- Converse.js: extraction automatique du pseudo depuis le JID. [V1ct0r]
- Commentaires des scamreport ne sont plus tronqués #278. [V1ct0r]
- Meilleur affichage des fils de discussion de feedbacks #280. [V1ct0r]
- Texte des feedbacks non tronqué #280. [V1ct0r]
- Utilisation de l'API v2 bitcoinaverage (indisponibilité de la V1)
  [V1ct0r]
- Correction de l'affichage de la disponibilité sur page de listing des
  escrows #274. [V1ct0r]
- Affichage de la date du création du compte sur le profil #276.
  [V1ct0r]
- Envoi d'un MP aux modos lors de post en scam-report #275. [V1ct0r]
- Update converse.js et suppression du code inutile #41. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Mise à jour changelog. [V1ct0r]
- Envoi du MP d'averissement lors de l'ouverture d'un scam-report.
  [V1ct0r]
- Correction affichage texte tronqué des scam-report #278. [V1ct0r]

version 1.6.0
------------------------
- Envoi du MP d'averissement lors de l'ouverture d'un scam-report.
  [V1ct0r]
- Upgrade version en v1.60. [V1ct0r]
- Ajout d'un lien pour bannir le rapporteur d'un scam-report. [V1ct0r]
- Ajout d'un avertissement sur le formulaire de scam-report. [V1ct0r]
- Amélioration de m'affichage des MP en moderation de scam-report.
  [V1ct0r]
- Affichage des scam_reports fermés. [V1ct0r]
- Affichage scamreport_detail closed. [V1ct0r]
- Update du message d'avertissement avant bannissement. [V1ct0r]
- Ajout du lien pour bannir l'utilisateur en moderation de scam-report.
  [V1ct0r]
- Amélioration de l'affichage des MPs en moderation de scam_report.
  [V1ct0r]
- Ajout lien d'affichage des MPs liés à un scam pour modos et mise à
  jour des urls, templates et noms de vue. [V1ct0r]
- Mise à jour tests fonctionnels. [V1ct0r]
- Ajout du changelog. [V1ct0r]
- Ajout d'un settings pour les tests fonctionnels. [V1ct0r]
- Mise à jour tests fonctionnels. [V1ct0r]
- Suppression des anciens tests fonctionnels. [V1ct0r]
- Test fonctionnel ouvre le formulaire de scam-report. [V1ct0r]
- Ajout de la créations de produits pour les tests fonctionnels.
  [V1ct0r]
- Creation de shops pour les tests fonctionnels. [V1ct0r]
- Creation de donnees initiales pour les tests fonctionnels. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Alert bootstrap pour augmenter visibilité du message d'erreur sur la
  page d'enregistrement #135. [V1ct0r]
- Utilisation d'une methode d'attente custom. [V1ct0r]
- Test fonctionnel test la connexion en tant que buyer. [V1ct0r]
- Ajout d'un commentaire. [V1ct0r]
- Et encore PEP8 + supression de reliquat de compatibilité python3
  puisqu'elle n'est plus assuré. [V1ct0r]
- Encore plus de pep8. [V1ct0r]
- Encore pep8. [V1ct0r]
- Plus de pep8. [V1ct0r]
- Ajout de la creation de group et d'user pour lestests fonctionnels +
  nouveau test. [V1ct0r]
- Nouveaux tests fonctionnels. [V1ct0r]
- Ajout d'un nouveau fichier de test fonctionnel #34. [V1ct0r]
- Leve une exception et renvoit 0 si le modele currency n'est pas
  initialisé #273. [V1ct0r]
- Ajout de allow_empty sur la vue home pour pouvoir executer les tests
  sur une DB vide. [V1ct0r]
- Modification mineure du template. [V1ct0r]
- Ajout de la vue de suppression des commentaires de scam-report.
  [V1ct0r]
- Ajout de la vue de modification des commentaires de scam-report.
  [V1ct0r]
- Correction template. [V1ct0r]
- Ajout des commentaires de scam-report et de la vue pour les ajouter.
  [V1ct0r]
- Ajout du lien du scam-report au message d'avertissement. [V1ct0r]
- Ajout du menu de moderation aub template scamreport_detail. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Ajout de vue de suppression d'un scam-report. [V1ct0r]
- Suppression d'une methode inutile. [V1ct0r]
- Ajout de vue de suppression d'un scam-report. [V1ct0r]
- Supression d'occurences print de debogage. [V1ct0r]
- Ajout de get_absolute_url au modele account. [V1ct0r]
- Ajout du template de modification du scam report. [V1ct0r]
- Implementation vue et url update scam_report. [V1ct0r]
- Amelioration template scamreport_detail. [V1ct0r]
- Ajout d'un lien vers la liste des SR en page d'acceuil. [V1ct0r]
- Pas d'affichage des scam-report fermés. [V1ct0r]
- Supression de code commenté. [V1ct0r]
- Ajout de la liste de scam-report. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Ameliorations. [V1ct0r]
- Ajout des scam_report en admin. [V1ct0r]
- Utilisation de get_absolute url et de reverse pour scam_report detail.
  [V1ct0r]
- Creation de la vue detail du scam_report. [V1ct0r]
- Formulaire de scam/report met à jour le modele scam_report. [V1ct0r]
- Supression du lien vers scam/report pour soi-même. [V1ct0r]
- Nom de context plus explicite et moins agressif. [V1ct0r]
- Ajout du fingerprint de l'expediteur à la vue de lecture des MPs #122.
  [V1ct0r]
- Formulaire d'ouverture de scam/report non fonctionnel #191. [V1ct0r]
- Modeles pour scam/report #191. [V1ct0r]
- Base pour scam/report #191. [V1ct0r]
- Suppression du message d'avertissement pour les majuscules. [V1ct0r]
- Correction typo et mise en page. [V1ct0r]
- Ajout d'un lien vers la liste complete des utilisateurs sur la page
  about #271. [V1ct0r]
- Fingerprint est maintenant une property du modele Account. [V1ct0r]
- Champ admin_msg du formulaire banuser pre-rempli avec le contenu du
  modele. [V1ct0r]
- Ajout d'un message si l'utilisateur est déjà banni. [V1ct0r]
- Ajout de l'url pour l'action POST. [V1ct0r]
- Affichage du nom de l'utilisateur à bannir et d'un texte
  d'avertissement  #134. [V1ct0r]
- Ajout du contenu initial pour le motif de bannissement #134. [V1ct0r]
- Fonction de bannissement accessible uniquement aux modos. [V1ct0r]
- Simple fonction bannissement utilisateur fonctionnelle #134. [V1ct0r]
- Ajout d'une updateview non fonctionnellepour bannissement utilisateur.
  [V1ct0r]
- Supression d'un import inutile. [V1ct0r]
- Fonction naive fonctionnelle de tri par émetteur et destinataire avec
  affichage d'un maximum d'info des MPs en scam/report accessible
  uniquement pour les modos #134. [V1ct0r]
- Fonction naive fonctionnelle de tri des MPs en scam/report #134.
  [V1ct0r]
- Naive query en moderation. [V1ct0r]
- Correction regression => test id_fdw à nouveau en majuscule # 134.
  [V1ct0r]
- Start new app moderation. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Couleur des boutons sur la page avertissement avant inscription.
  [V1ct0r]
- Ajout des liens sur la page avertissement avant inscription. [V1ct0r]
- Ajout d'un signal pour redimensionner et anonymiser avec MAT les
  bannières publicitaires #165. [V1ct0r]
- Ajout d'une ligne sur le formlaire d'inscription pour les majuscules
  dans l'identifiant FDW. [V1ct0r]
- Correction typo. [V1ct0r]
- Ajout du texte pour l'avertissement avant inscription et modification
  des liens #269. [V1ct0r]
- Ajout d'un template pour info su risques avant inscription #269.
  [V1ct0r]
- VerifyVendorForm est juste un Form et non un ModelForm. [V1ct0r]
- Modification du modelform pour prendre en compte l'ajout du groupe
  vendor. [V1ct0r]
- Leve une exception pour afficher un champ fingerprint vide en cas
  d'erreur de clef. [V1ct0r]
- Merge branch '122-fonctionnalites-gpg' into 'master' [V1ct0r]

  ajout du fingerprint de la cle openPGP sur le profil #122

  See merge request !15
- Ajout du fingerprint de la cle openPGP sur le profil #122. [V1ct0r]
- Merge branch 'get_vendor_rights' into 'master' [V1ct0r]

  Get vendor rights

  See merge request !14
- Ajout du lien pour devenir vendeur sur page de profil. [V1ct0r]
- Utilisation d'une FormView pour le formulaire de demande de droits
  vendeur. [V1ct0r]
- Supression du template inutilisé usercreate. [V1ct0r]
- Les vendeurs ne peuvent pas afficher le formulaire d'ajout des droits
  vendeur. [V1ct0r]
- Supression de la view inutilisée 'CreateProfile' [V1ct0r]
- Supression de la view inutilisée "createprofile" [V1ct0r]
- Supression de la vue inutilisée "create_profile" [V1ct0r]
- ProfileUpdate redirige sur page de profil. [V1ct0r]
- Redirige sur le profil après obtention des droits vendeur. [V1ct0r]
- Formulaire droits vendeur fonctionnel. [V1ct0r]
- Leve toutes les exceptions lors de la demande de compte vendeur.
  [V1ct0r]
- Better print debuf for work. [V1ct0r]
- Get request user in form. [V1ct0r]
- Merge branch 'get_vendor_rights' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket into
  get_vendor_rights. [V1ct0r]
- Simple check gpg signature non fonctionnelle. [V1ct0r]
- Simple check gpg signature. [V1ct0r]
- Update settings for django-debug-toolbar. [V1ct0r]
- Esquisse de la fonction droits vendeur. [V1ct0r]
- Update configuration pour production. [V1ct0r]
- Suppression d'une instructionprint de débogage. [V1ct0r]
- Merge branch 'minizoom' into 'master' [V1ct0r]

  Zoom fiche produit

  See merge request !13
- Zoom fiche produit. [lutinmalin]

  zoom *1.5 sur la fiche produit (toujours zoom *2 dans les listes).
  Retouche affichage responsive fiche produit
- Correction bug filtertag n'affichant que l'image par defaut. [V1ct0r]
- Merge branch '264' into 'master' [V1ct0r]

  Issue 264

  See merge request !12
- Issue 264. [lutinmalin]

  La banniere est à nouveau redimensionnée avec la fenêtre du navigateur
- Remove the font import from google. [V1ct0r]
- Merge branch 'menuflex' into 'master' [V1ct0r]

  Barre de menu

  See merge request !11
- Update base.html. [Lutin]
- Barre de menu. [lutinmalin]

  Barre de menu en CSS flex, sans Javascript.
  Modifs légères du template base.
- Merge branch 'Neolidas' into 'master' [V1ct0r]

  Neolidas

  Création d'un template filter pour éviter TypeError si image absente dans une des bannières publicité ##261
- Passage de BASE_DIR à MEDIA_ROOT pour le path. [John Doe]
- Issue #261 Ajout d'un filtre sur l'url de l'image, si l'image n'est
  pas trouvée en local, une image par défaut est alors affichée. [John
  Doe]
- Update README.md. [V1ct0r]
- Update README.md. [V1ct0r]
- Ajout d'une note d'installation en cas de blocage avec les
  contenttypes. [V1ct0r]
- Correction typo. [V1ct0r]
- Upgrade version to 1.5.5b. [V1ct0r]
- Supression du vieux code commenté, clean code pour pep8. [V1ct0r]
- Choix du motif d'absence est une liste de choix pour eviter les abus,
  formatage de account.models plus pep8. [V1ct0r]
- Merge branch 'lutinmalin' into 'master' [V1ct0r]

  Mode absence

  See merge request !9
- Mode absence. [lutinmalin]

  Le booleen vacances devient une string absence.
  Remplacement des alertes en texte brut par des alertes bootstrap warning dans tous les modèles.

  Bonus : modif. des instructions de la page contact (car compte anonymous désactivé sur le gitlab)
- Levée d'une exception dans queryfdw pour les parametres de prod et de
  dev, maintien de la compatibilite de python < 3.6. [V1ct0r]
- Maintien de la retro-compatibilite avec python < 3.6. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Merge branch 'lutinmalin' into 'master' [V1ct0r]

  Modifications pub et affichage

  See merge request !8
- Modifications pub et affichage. [lutinmalin]

  Suppression de la bande bleue et du texte de pub. Image centrée. Lien sur toute l'image. Dimensions 1300*300px.
  Correction bug affichage mode colonne
- Settings pour dev et levee d'exception dans les signaux pour selection
  de MEDIA_ROOT en prod. [V1ct0r]
- Ajout de la nouvelle version sur le footer. [V1ct0r]
- Add settings_prod to gitignore. [V1ct0r]
- Modification max size img products. [V1ct0r]
- Correction du nom du contexte dans le tri par categories. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Update version. [V1ct0r]
- Retour sur chemin relatif pour la DB. [V1ct0r]
- Modification de la variable MEDIA_ROOT dans settings.py et import
  depuis settings_prod dans signals.py #254. [V1ct0r]
- Merge branch 'lutinmalin' into 'master' [V1ct0r]

  Lutinmalin

  See merge request !7
- Affichage ligne Choix entre affichage ligne et affichage colonne dans
  les options du profil Légères retouches de l'affichage colonne et de
  la page Modifier votre profil. [lutinmalin]
- Mode vacances Mise en place du mode vacances avec notification dans
  tous les templates concernés (sauf compose) - Issue #238 Remise en
  place du bogue de pagination dans shop_detail Légères modifs
  esthétiques. [lutinmalin]
- Fonction recherche ! Mise en place d'une fonction de recherche dans la
  page d'accueil - recherche nom + description - Issue #119.
  [lutinmalin]
- Traductions manquantes - texte et no-pre.png corrections ajustement
  CSS-Slider - issue #186 taux bitcoin flottant et prix flottants
  (perso/css/style.css) modif jumbotron escrows (perso/css/style.css)
  mise à jour de requirements.txt modification de l'affichage des
  produits modification de la pagination - issue #223 création de
  templates pagination et affichage des produits. [lutinmalin]
- Traduction image no-pre. [lutinmalin]
- Update requirements.txt. [Lutin]
- Update requirements (et test git push)  modifié:
  requirements.txt. [lutinmalin]
- Add urls for deploying the DDTB on the preprod-server. [V1ct0r]
- Merge branch 'v1.5.4' into 'master' [V1ct0r]

  V1.5.4

  See merge request !6
- Ajout de la levée de l'exception FileNotFoundError sur le traitment de
  l'avatar par pil #253. [V1ct0r]
- Update initial fixture. [V1ct0r]
- Possibilité de tri différents sur la page de listing des escrows #219.
  [V1ct0r]
- Correction du nom du vendeur dans le template shop_detail. [V1ct0r]
- Correction du tri par nouveauté sur le template home. [V1ct0r]
- Amélioration du template de profil. [V1ct0r]
- Template shops_list pour tri des shops. [V1ct0r]
- Ajout des feedbacks sur les shops. [V1ct0r]
- Feedbacks likes, unlikes, nbre_feedbacks sont mainteant des properties
  du modele Account. [V1ct0r]
- Logique de tri pour la page de listing des escrow #219. [V1ct0r]
- Upgrade template en v1.5.4. [V1ct0r]
- Logique de tri pour la page de listing des shops #219. [V1ct0r]
- Ajout du tri par nouveautés en page home #249. [V1ct0r]
- Ajout de date de création et d'update à tous les modèles. [V1ct0r]
- Remplacement des urls en dur par des reverse(#38), correction
  d'url(#242), publicity.url vide autorisée qui pointe sur le shop par
  defaut, et suppression du lien de redirection vers l'interface
  d'administration sur la page de changement de password. [V1ct0r]
- Working on #38. [V1ct0r]
- Working on #38 inside base.html l100. [V1ct0r]
- Ordre aleatoire des bannieres publicitaures #245. [V1ct0r]
- Couleurs differentes pour message du staff #244. [V1ct0r]
- Correction du lien cassé d'envoi de message depuis le shop #241.
  [V1ct0r]
- Ajout d'un champs note dans le model publicity #240. [V1ct0r]
- Customise admin pour model Publicity #240. [V1ct0r]
- Ajout de notes d'installation pour termux. [V1ct0r]
- Ajout de l'interdiction du viol dans les CGU afin que ce soit plus
  explicite. [V1ct0r]
- Réecriture de la commande de management d'effacement des messages
  #229. [V1ct0r]
- Correction script de commande de management pour l'effacement des MPs
  supprimés #239. [V1ct0r]
- Oubli d'update de la version dans le footer. [V1ct0r]
- Utilisation interpolation de variables pour regler les problèmes de
  majuscules et de caractère spéciaux qui induisent un risque
  d'injection sql dans le formulaire de création de compte #225, #134.
  [V1ct0r]
- Les comptes désactivé ne doivent pas être listé en page aout #233.
  [V1ct0r]
- Problème de sensibilité à la casse lors de l'enregistrement =>
  conversion en majuscule pour la verification de l'id_FDW  #134.
  [V1ct0r]
- Ajout d'info sur le modele Publicity pour mieux gerer son affichage
  depuis l'administration #235. [V1ct0r]
- Copie des fichiers fonts dans le bon repertoire #234. [V1ct0r]
- Merge branch 'Neolidas' into 'master' [V1ct0r]

  Ajout du fichier css

  ajout du fichier css disparu

  See merge request !5
- Ajout du fichier css. [john doe]
- Update base.html with version. [V1ct0r]
- Merge branch 'v1.5.2' into 'master' [V1ct0r]

  V1.5.2

  See merge request !4
- Leve une exception quand un vendeur cree un produit sans avoir de shop
  et cree automatiquement le shop #190. [V1ct0r]
- Rectification url category #90 et utilisation templatag url category.
  [V1ct0r]
- Message du staff visible sur page home et prducts #140. [V1ct0r]
- Message du staff visible sur page shop et product_detail #140.
  [V1ct0r]
- Add users listing #205. [V1ct0r]
- Add link to the shop on vendor profil and products #221. [V1ct0r]
- Add pages link on top #224. [V1ct0r]
- Correction orthographe sur page conditions utilisations. [V1ct0r]
- Update link in sign in page #232. [V1ct0r]
- Modify login template for not have login page when we are log in #227.
  [V1ct0r]
- Tri par differente methode en page home #219. [V1ct0r]
- Update templates for django 1.10 compatibility #220. [V1ct0r]
- #228 remplacement de pyvenv(déprécié) par python -3 venv. [V1ct0r]
- Update requirements for django==1.9.9. [V1ct0r]
- Update urls.py for log-in/out, sign-in with name. [V1ct0r]
- Fixe le nombre d'element par page à 21 #222. [V1ct0r]
- Update README for #228. [V1ct0r]
- Merge branch 'v1.5.1' into 'master' [V1ct0r]

  V1.5.1



  See merge request !3
- Merge branch 'v1.5.1' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket into v1.5.1.
  [V1ct0r]
- Better to sort by price for shop.products listing. [V1ct0r]
- #218 pagination for shops.products listing, random sorted. [V1ct0r]
- Clean code / random sorted escrow. [V1ct0r]
- Update version to v1.5.1. [V1ct0r]
- Ajout d'un champ pour editer le message personnel de l'escrow si
  l'utilisateur est dans le groupe escrow #141. [V1ct0r]
- Correct templates bootstrap for correct place of pagination #217.
  [V1ct0r]
- Clean code. [V1ct0r]
- Clean code. [V1ct0r]
- #184 paginate & random order for escrow listing. [V1ct0r]
- Typo correction. [V1ct0r]
- Clean code. [V1ct0r]
- Clean code. [V1ct0r]
- #184 : paginate for shops list. [V1ct0r]
- #184 paginate on home page, need escrows and shops. [V1ct0r]
- Working on #184 : paginate for home page. [V1ct0r]
- Add random sorted products to home page. [V1ct0r]
- Pagination for products list #184. [V1ct0r]
- Add category field in product admin for resolve #116. [V1ct0r]
- #142 pages About Contact, Rules review. [V1ct0r]
- Reecriture readme, simplification installation (bug
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket/issues/214) [V1ct0r]
- Upgrade fixtures for easy install. [V1ct0r]
- Upgrade requirements. [V1ct0r]
- Updatecurrency raise exception when object does not exist. [V1ct0r]
- Cleaning code. [V1ct0r]
- Remove checkbox superuser for non superuser in admin
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket/issues/206. [V1ct0r]
- Upgrade fixtures with new moels implementation for feedbacks. [V1ct0r]
- Add account admin  search in admin. [V1ct0r]
- Correctif  Issue #212 (staff message no longer appears) [V1ct0r]
- Fix message tronqué dans la vue detaillée du feedback  #210. [V1ct0r]
- Templates typo correction. [V1ct0r]
- Update README.md. [V1ct0r]
- Delete unused js. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Merge branch 'dev' into 'master' [V1ct0r]

  Update README.md "Francophone" not "Française"



  See merge request !2
- Update README.md "Francophone" not "Française" [azymoth]
- Use Account.slug in place of User in feedbacks (correction bug) delete
  default datetime in feedbacks(The options auto_now, auto_now_add, and
  default are mutually exclusive. Only one of these options may be
  present.) code cleaning. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Add date default to feedbacks. [V1ct0r]
- Cleanup. [V1ct0r]
- Call feedback via account.slug (bug correctif) [V1ct0r]
- Remove bootstrap bakups. [V1ct0r]
- Cleaning. [V1ct0r]
- Clean repo. [V1ct0r]
- Merge branch 'merriadoc' into 'master' [V1ct0r]

  Modifs ads & gitkeeps

  Added gitkeeps to have a correct direcoctory structure, edited the corresponding warning in the  readme.md.
  Edited the way ads are shown to avoid errors when they have no image.

  See merge request !1
- Delete comment feedback ok. [V1ct0r]
- Update feedback ok, need link. [V1ct0r]
- Link for add feedback comment. [V1ct0r]
- Simple add comment view. [V1ct0r]
- Avoid request by non poster feedback for deletion. [V1ct0r]
- Add protection and links on various page for feedbacks. [V1ct0r]
- Add protection to avoid an user modify a feedback writen by another
  user. [V1ct0r]
- Adding protection to avoid user sending request to assign feedback to
  himself, basic delete feedback. [V1ct0r]
- Add link for modify feedback by poster. [V1ct0r]
- Update feedback only by poster (need link in detail view) [V1ct0r]
- Basic view for display one feedback and his comments. [V1ct0r]
- Table for userfeedback detail. [V1ct0r]
- Basic feedback detail. [V1ct0r]
- Add user feedback comment. [V1ct0r]
- Clean template. [V1ct0r]
- Use table for a better look of feedbacks list. [V1ct0r]
- Clean up. [V1ct0r]
- Format des messages du staff et de l'escrow
  (http://haklab4ulibiyeix.onion/devmarket/fdwmarket/issues/139)
  [V1ct0r]
- Add feedback better template, working link, hack for good
  get_success_url. [V1ct0r]
- Good look for list user feedbacks. [V1ct0r]
- Average rounded to two digits after the decimal point. [V1ct0r]
- List feedbacks for one user ok. [V1ct0r]
- Correct profil with feedbacks. [V1ct0r]
- Update fixtures. [V1ct0r]
- Merge branch 'feedbacks' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket into feedbacks.
  [V1ct0r]
- Fixtures clean & news. [V1ct0r]
- Merge branch 'feedbacks' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket into feedbacks.
  [V1ct0r]
- Starting feedbacks views. [V1ct0r]
- Clean up. [V1ct0r]
- Clean up. [V1ct0r]
- Ok models feedbackuser. [V1ct0r]
- More info in admin and start feedbacks. [V1ct0r]
- Merge branch 'feedbacks' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket into feedbacks.
  [V1ct0r]
- Working add feedbackuser. [V1ct0r]
- Update feedbacks and view. [V1ct0r]
- Update feedbacks. [V1ct0r]
- Add feedbacks basic ok. [V1ct0r]
- Update feedbacks. [V1ct0r]
- Update feedbacks. [V1ct0r]
- Update feedbacks. [V1ct0r]
- Correctif. [V1ct0r]
- Correct link to account in view MP template. [V1ct0r]
- Correct link to slug in template MP. [V1ct0r]
- Link for sender and recipient in template message. [V1ct0r]
- Add django_messages templates project directory. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Add origin od css-slider. [V1ct0r]
- Add missing import os. [V1ct0r]
- Add name for publiity in admin. [V1ct0r]
- Better dimension. [V1ct0r]
- Down slider height. [V1ct0r]
- Add url link pub.name. [V1ct0r]
- Slider with templatetag ok. [V1ct0r]
- Typo correction. [V1ct0r]
- Second try without templatetag. [V1ct0r]
- Ok slider, need templatetag. [V1ct0r]
- 1st try. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Typo et commentaire sur partie non fonctionnelle. [V1ct0r]
- Installation app tables in django1.9. [V1ct0r]
- Url is not a valid tag or filter in tag library future, url is now
  load by default. [V1ct0r]
- Correction to settings.py. [V1ct0r]
- Remove working directory. [V1ct0r]
- Update settings for django 1.9. [V1ct0r]
- Update urls.py for django1.10. [V1ct0r]
- Beta version because all fix for 1.5 not all done. [V1ct0r]
- Update requirements. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Add info for pillow compilation. [V1ct0r]
- Modify settings for django1.9 compatibility. [V1ct0r]
- Update settings.py. [V1ct0r]
- Fix templating error when an ad as no image. [Merriadoc]
- Added .gitkeep in migrations folders. [Merriadoc]

  To avoid to have to create them after cloning
  Stroked the part dealing with it in the readme
- Merge branch 'master' into dev. [V1ct0r]
- Correct permission error when signal delete metadatas in
  account.avatar. [V1ct0r]
- Correction de l'indentation des catégories et suppression d'un point
  parasite sur la page escrow. [localhost]
- Replace raw media url by {{ MEDIA_URL }} [V1ct0r]
- Message de l'escrow. [V1ct0r]
- Merge branch 'dev' [V1ct0r]
- Amélioration de l'interface. [localhost]
- Permission correction. [V1ct0r]
- Merge branch 'dev' numero de version. [V1ct0r]
- Changement de version. [localhost]
- Ajout de dependances manquantes. [V1ct0r]
- Merge branch 'dev' Neolidas work on templates. [V1ct0r]
- Merge branch 'dev' of haklab4ulibiyeix.onion:devmarket/fdwmarket into
  dev. [localhost]
- Nouveau fichier css. [localhost]
- Evolution de l'interface. [localhost]
- Delete bad copy/paste. [V1ct0r]
- Merge branch 'dev' update README. [V1ct0r]
- Modify reference to django docs. [V1ct0r]
- Modification du README.md. [localhost]
- Modification du README.md. [localhost]
- Merge branch 'dev' [V1ct0r]

  Conflicts:
  	README.md
- Modification du README.md. [localhost]
- Typo correction. [V1ct0r]
- Typo correction in readme. [V1ct0r]
- More flexbility for publicity banner administration. [V1ct0r]
- Typo correction in publicity. [V1ct0r]
- Update settings.py for publicity management. [V1ct0r]
- Correct typo. [V1ct0r]
- Correct typo. [V1ct0r]
- Add pub management. [V1ct0r]
- Update pub. [V1ct0r]
- Update pub. [V1ct0r]
- Solved conflict. [V1ct0r]
- Update pub. [V1ct0r]
- Update pub. [V1ct0r]
- Update pub. [V1ct0r]
- Update pub. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]
- Typo in pub. [V1ct0r]
- Update pub. [V1ct0r]
- Add helper for displaying sorted categories. [V1ct0r]
- Merge branch 'master' of haklab4ulibiyeix.onion:devmarket/fdwmarket.
  [V1ct0r]
- Update Readme, link in https for mysql-connector. [V1ct0r]
- Update readme. [V1ct0r]
- Update initial datas. [V1ct0r]
- Only modo with add category permission can add category. [V1ct0r]
- Keep proportion when resize product and enseigne images. [V1ct0r]
- Correct resize avatar. [V1ct0r]
- Simplify resize avatar. [V1ct0r]
- Update readme for pillow installation, new theme for profil_detailn
  update signal for better modify size of avatar(need more work)
  [V1ct0r]
- Addd reset database instructions. [V1ct0r]
- Update initial data and update readme for installation. [V1ct0r]
- Update initial fixture. [V1ct0r]
- Update readme, add missing password creation for test users. [V1ct0r]
- Update readme, create test user is now a fonction. [V1ct0r]
- Update readme & delete M2M from feedbacks. [V1ct0r]
- New pub owner. [V1ct0r]
- Merge branch 'dev' of haklab4ulibiyeix.onion:devmarket/fdwmarket into
  dev. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]

  Conflicts:
  	shops/templates/shops/escrow.html
- Add pub in hard, need to do more DRY. [V1ct0r]
- Add {{ form.error }} [V1ct0r]
- Merge branch 'feedbacks' [V1ct0r]
- Damocles theme for sign_up. [V1ct0r]
- Try to add damocles theme for inscription. [V1ct0r]
- Merge branch 'feedbacks' [V1ct0r]
- Correct typo. [V1ct0r]
- Add license. [V1ct0r]
- Try to hide escrow_msf field if User.is_authenticated() is not escrow
  (https://docs.djangoproject.com/en/dev/ref/contrib/auth/#django.contri
  b.auth.models.User.get_username) [V1ct0r]
- Clean code, add escrow_msg field. [V1ct0r]
- Good look for escrows page. [V1ct0r]
- Merge branch 'master' into feedbacks. [V1ct0r]
- Merge branch 'master' into feedbacks for update profil template.
  [V1ct0r]
- Start try to implement feedbacks. [V1ct0r]
- Good look for escrows page. [V1ct0r]
- Start integrate damocles theme for escrows. [V1ct0r]
- Merge branch 'master' of haklab4ulibiyeix.onion:devmarket/fdwmarket.
  [V1ct0r]
- Update. [V1ct0r]
- Use .format instead of old style string formating. [V1ct0r]
- Update profil template. [V1ct0r]
- Add local ttf files for avoid loading them in cw. [V1ct0r]
- Update login.html. [V1ct0r]
- Set password trype on login. [V1ct0r]
- Login html by Damocles. [V1ct0r]
- Remove verbose name from shops appconfig. [V1ct0r]
- Home listing order by photo. [V1ct0r]
- Add shops feedback, likes and inlikes. [V1ct0r]
- More visibl link to profile in shop, link to MP Vendor in Shop.
  [V1ct0r]
- Remove css with bad look in main.css. [V1ct0r]
- Link message again in the top bar. [V1ct0r]
- Modify alert color in bootstrap-theme, remove non used css link in
  base and replace non working css tag in escrow. [V1ct0r]
- Add count total number of users on about. [V1ct0r]
- Use slate template for first integration in prod. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]
- Use %static instead of raw link. [V1ct0r]
- New theme for contact. [V1ct0r]
- New theme now for about. [V1ct0r]
- New theme ok for rules. [V1ct0r]
- Start new theme for rules, add js files. [V1ct0r]
- Good path to home logo not connected. [V1ct0r]
- New theme integration ok for base. [V1ct0r]
- Start integrate new theme. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]
- Update bootstrap. [V1ct0r]
- Raise error on hashlib. [V1ct0r]
- Remove debug print statement. [V1ct0r]
- Now running mat only if file exist(avoid error 502), call mat with
  subprocess.call instead of getoutput. [V1ct0r]
- Back MAT working. [V1ct0r]
- Merge branch 'master' of haklab4ulibiyeix.onion:devmarket/fdwmarket.
  [V1ct0r]
- Use aggregation for the listing of users on about. [V1ct0r]
- Raise error for MAT. [V1ct0r]
- MAT power and resize ok for account avatar. [V1ct0r]
- Start MAT power and resize for account avatar. [V1ct0r]
- Add exception handling when we delete image. [V1ct0r]
- MAT power and resize for Shop enseigne. [V1ct0r]
- Remove debug print statement. [V1ct0r]
- MAT power and resize for product photo. [V1ct0r]
- Working MAT power. [V1ct0r]
- Update README. [V1ct0r]
- Update signals MAT don't working. [V1ct0r]
- MAT integration not working) use MEDIA_ROOT for define path. [V1ct0r]
- Update subprocess power for MAT, DON'T WORK, BAD PATH. [V1ct0r]
- Add subprocess power for MAT, DON'T WORK, BAD PATH. [V1ct0r]
- Add print statement and subprocess fonction to prepare the signal
  staff on product image. [V1ct0r]
- Add print statement to prepare the signal staff on product image.
  [V1ct0r]
- Add print statement for Shop & Product pre_save() signals. [V1ct0r]
- Merge branch 'signals' [V1ct0r]
- Pep8. [V1ct0r]
- Start working with signals. [V1ct0r]
- Update template. [V1ct0r]
- Update template. [V1ct0r]
- Update template. [V1ct0r]
- Update template. [V1ct0r]
- Price in btc now rounded to 5 decimals. [V1ct0r]
- Remove user.email from admin because we use account.email now,
  rearrange fields. [V1ct0r]
- Update README. [V1ct0r]
- Typo. [V1ct0r]
- Update & correction of README. [V1ct0r]
- Email is now in Account. [V1ct0r]
- Add missing modifify profile fields. [V1ct0r]
- Back working state, need ro clean code. [V1ct0r]
- Add last_login to admin. [V1ct0r]
- Non working state for trying email in modify profile. [V1ct0r]
- Start form for modofy profile in email. [V1ct0r]
- Start add email to modify profile form. [V1ct0r]
- Back before modifuser. [V1ct0r]
- Try can modify email. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]
- Back to working view for update profil. [V1ct0r]
- Clean forms since save email is ok. [V1ct0r]
- Try to save email 3. [V1ct0r]
- Try to save email 2. [V1ct0r]
- Try to save email(typo correction for reverse) [V1ct0r]
- Better rendering for price, upgrade requirements.txt. [V1ct0r]
- Price in btc in templates, need better rendering. [V1ct0r]
- Typo. [V1ct0r]
- Test using property for price in btc. [V1ct0r]
- Merge branch 'master' of
  http://haklab4ulibiyeix.onion/devmarket/fdwmarket. [V1ct0r]
- Typo. [V1ct0r]
- Typo. [V1ct0r]
- Update readme. [V1ct0r]
- Cyan for btc rate in template and management command for delete
  message. [V1ct0r]
- Update requirements. [V1ct0r]
- Update readme. [V1ct0r]
- Update readme. [V1ct0r]
- Update readme. [V1ct0r]
- Update readme. [V1ct0r]
- Update readme. [V1ct0r]
- Update readme for btc_rate installation. [V1ct0r]
- Bigger btc_rate. [V1ct0r]
- Btc_rate is now a context_processor. [V1ct0r]
- Working currency btc rate. [V1ct0r]
- Management-command for update currency ok. [V1ct0r]
- Add link about command manager. [V1ct0r]
- Model for get the management command for update btc rate. [V1ct0r]
- Merge branch 'master' of haklab4ulibiyeix.onion:devmarket/fdwmarket.
  [V1ct0r]
- Add missing docstring & add directory for management command. [V1ct0r]
- Pep8. [V1ct0r]
- Add script for update currency. [V1ct0r]
- Merge branch 'master' of haklab4ulibiyeix.onion:devmarket/fdwmarket.
  [V1ct0r]
- Add models for currency change rate. [V1ct0r]
- Typo error. [V1ct0r]
- Add script for btc rate. [V1ct0r]
- Merge branch 'master' of haklab4ulibiyeix.onion:devmarket/fdwmarket.
  [V1ct0r]
- Resolv the accent error 500, try to add # -*- coding: utf-8 -*-
  everywhere. [V1ct0r]
- Resolv the accent error 500, new test. [V1ct0r]
- Resolv the accent error 500, the good file :/ [V1ct0r]
- Resolv the accent error 500. [V1ct0r]
- Correct language_code. [V1ct0r]
- Merge branch 'master' of haklab4ulibiyeix.onion:devmarket/fdwmarket.
  [V1ct0r]
- Color of logo. [V1ct0r]
- Typo. [V1ct0r]
- Remove logo noel. [V1ct0r]
- Oups the test. [V1ct0r]
- Revert "new about" [V1ct0r]

  This reverts commit 93707c87201e949268ca6cec949df0cb05bd4f9d.
  back in working state
- Merge branch 'master' into dev for test ad email to create user.
  [V1ct0r]
- Correct typo. [V1ct0r]
- Test post save email correction. [V1ct0r]
- Test for add emailfield in create user form. [V1ct0r]
- Test post save email correction. [V1ct0r]
- Test post save email. [V1ct0r]
- Add email to signup form. [V1ct0r]
- New about. [V1ct0r]
- Workink list users on about. [V1ct0r]
- Try listusers. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]
- Update about. [V1ct0r]
- Typo. [V1ct0r]
- Typo. [V1ct0r]
- CGU. [V1ct0r]
- Rules view. [V1ct0r]
- Merge branch 'dev' of haklab4ulibiyeix.onion:devmarket/fdwmarket into
  dev. [V1ct0r]
- Test déplacer le texte et l'avatar. [error69]
- Test avatar en position absolute. [error69]
- Update readme. [V1ct0r]
- Test avec une position relative pour empêcher les blocs de se
  chevaucher en cas de petit écran. [error69]
- Update readme. [V1ct0r]
- Correct installation. [V1ct0r]
- Staff message in escrows list page. [V1ct0r]
- Auto jid to username@fdw.libertygb2nyeyay.onion. [V1ct0r]
- Couleur : gris. [error69]
- Test bloc : well. [error69]
- Update README.txt. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]
- Noel logo for home page. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]
- Replace send message to link to profile on the escrow listing.
  [V1ct0r]
- Display number of new message in menu only if there is new message.
  [V1ct0r]
- Useless file, we have snippet. [V1ct0r]
- Display numbers of new messages in menu. [V1ct0r]
- Remove bad merging. [V1ct0r]
- Remove bad merging. [V1ct0r]
- Merge branch 'master' into dev. [V1ct0r]

  Conflicts:
  	account/models.py
  	account/queryfdw.py
- Fix banner to 500x180 for shops list and remove class="img-responsive"
  for shops list. [V1ct0r]
- Fix banner to 500x180 for shops list. [V1ct0r]
- Fix banner height to 168 for shops list. [V1ct0r]
- Fix avatar size to 128x128. [V1ct0r]
- A little better Mp theme integration. [V1ct0r]
- Better escrow template. [V1ct0r]
- Add django_messages templates into templatedir. [V1ct0r]
- Add link to FDW profile on the profile. [V1ct0r]
- Add send PM link to profile. [V1ct0r]
- Add missing quote. [V1ct0r]
- Default to queryfdw id to 0. [V1ct0r]
- Add query fdw_id. [V1ct0r]
- Queryfdw wityh only username as parameter for more object usages and
  model fdw_id. [V1ct0r]
- Query with only fdw_identity as parameter. [V1ct0r]
- Id fdw with fdw identity. [V1ct0r]
- Test models with fdw id. [V1ct0r]
- Queryfdw pid ok. [V1ct0r]
- Test queryfdw for id. [V1ct0r]
- Typo. [V1ct0r]
- Link create account on home and link to category list on category
  detail. [V1ct0r]
- Update and correct. [V1ct0r]
- Better message and design for sign up. [V1ct0r]
- Signup view and remove createuser view. [V1ct0r]
- Start mixing signupand createuser. [V1ct0r]
- Remove debug print. [V1ct0r]
- Change localisation of fdw db settings because of the global DATABASES
  attributes not compatible with our settings. [V1ct0r]
- Remove debug print. [V1ct0r]
- Correct typo. [V1ct0r]
- Correct typo. [V1ct0r]
- Clean method with super and real test. [V1ct0r]
- Clean method with super and fake test. [V1ct0r]
- Add import for queryfdw. [V1ct0r]
- Initiate datasql variable. [V1ct0r]
- Update queryfdw and requirements. [V1ct0r]
- Helper class fdwquery and settings.py for fdw-db. [V1ct0r]
- Add staff field in profile. [V1ct0r]
- Correct typo and add correct staff restricted access to usercreate
  view. [V1ct0r]
- Update sign_up. [V1ct0r]
- Working usercreate view with fake test, url is_staff protected.
  [V1ct0r]
- Saving the account with just one field. [V1ct0r]
- Update requirements. [V1ct0r]
- Createuser with fake test for account. [V1ct0r]
- Createuser with all field, start fake trst for account. [V1ct0r]
- Createuser with all field, just create user. [V1ct0r]
- Createuser just create user. [V1ct0r]
- Try the builin createuser form. [V1ct0r]
- Need explication. [V1ct0r]
- Next step to the createuser. [V1ct0r]
- Createuser form, password is send in raw so is not saved  ?? [V1ct0r]
- Add templates files bakup for bootstrap admin. [V1ct0r]
- Try createview with custom form not work. [V1ct0r]
- Bootstrap admin logout without javascript ok. [V1ct0r]
- Use bootstrap-django-admin. [V1ct0r]
- Customize admin update requirements. [V1ct0r]
- Start add templates for private-messages. [V1ct0r]
- Correct the typo in modify shop template. [V1ct0r]
- Truncate description in list product and shop, and use linebreaks for
  <br /> in text description. [V1ct0r]
- Delete the related_name of account for come back to working profiles
  link. [V1ct0r]
- Add alert message on escrow page. [V1ct0r]
- Typo correction for pep8. [V1ct0r]
- Better custom list_display for user in admin and default for JID.
  [V1ct0r]
- Custom user list_display in admin. [V1ct0r]
- Not working add a column to the existing User admin. [V1ct0r]
- Example how to imply add a column to the existing User admin. [V1ct0r]
- Stackedinline for user account. [V1ct0r]
- Start stackedinline for account. [V1ct0r]
- Test createview for create user. [V1ct0r]
- Commented createview for registration. [V1ct0r]
- Start the fdw verification regitration. [V1ct0r]
- Correct typo in link for modify profile. [V1ct0r]
- Profle design add <pre> for gpg. [V1ct0r]
- Profle design from http://www.prepbootstrap.com/bootstrap-
  template/user-details. [V1ct0r]
- Correct Issue #79. [V1ct0r]
- Update settings.py. [V1ct0r]
- Update escrows link and add link to escrows profile in template.
  [V1ct0r]
- Basic escrow page with escrows list. [V1ct0r]
- Test escrow page with vendor. [V1ct0r]
- Slate them. [V1ct0r]
- Add the missing </a> [V1ct0r]
- Show all product in home page. [V1ct0r]
- Sort by category with bootstrap. [V1ct0r]
- Sort by category. [V1ct0r]
- Gitignore. [V1ct0r]
- Purge cache of gitignore. [V1ct0r]
- Show create shop when don't exist and show display shop when exist.
  [V1ct0r]
- Update README. [V1ct0r]
- Correct typo error in templatetag for link to profile. [V1ct0r]
- Basic link and templates for private messages. [V1ct0r]
- Restore the files for prod MP. [V1ct0r]
- Try to restore. [V1ct0r]
- Don't track settings.py. [V1ct0r]
- Private-Message. [V1ct0r]
- Product.shop need to be a forignkey, not a onetoone field. [V1ct0r]
- Try to add another <br/> tag for better shops list. [V1ct0r]
- Try to add a <br/> tag for better shops list. [V1ct0r]
- Try to add a <br/> tag for better shops list. [V1ct0r]
- Correct typo. [V1ct0r]
- Correct typo. [V1ct0r]
- Correct the typo in contact. [V1ct0r]
- Show product image. [V1ct0r]
- Update view and delete view protected in template ok. [V1ct0r]
- Correct th typo error for protect modify_product template. [V1ct0r]
- Updateview for modify product. [V1ct0r]
- Prepare the product modify view. [V1ct0r]
- Correct typo on the home page. [V1ct0r]
- Update about and contact pages. [V1ct0r]
- Resolve http://haklab4ulibiyeix.onion/devmarket/fdwmarket/issues/62.
  [V1ct0r]
- Resolve the uppercase bug. [V1ct0r]
- Remove the info for image resize, let it in comment. [V1ct0r]
- Add unique constraint to Shop.slug. [V1ct0r]
- Update modify profile view. [V1ct0r]
- Remove role abd comment pin from account model. [V1ct0r]
- Bootstrap theme for shops listing template. [V1ct0r]
- Unique contraint for product slug. [V1ct0r]
- Template for display shops. [V1ct0r]
- Add custom css for bootstrap. [V1ct0r]
- Listing product templates ok, delete the create profile link in menu.
  [V1ct0r]
- Correct the list products template. [V1ct0r]
- Merge branch 'master' of haklab4ulibiyeix.onion:devmarket/fdwmarket.
  [V1ct0r]
- Update change password. [V1ct0r]
- Add exemple view for redirect if not exist. [V1ct0r]
- Update account. [V1ct0r]
- Basic password change form from admin. [V1ct0r]
- Basic change password. [V1ct0r]
- Correct bug, start reset password. [V1ct0r]
- Fixture for test. [V1ct0r]
- Try again to protect modify_product. [V1ct0r]
- Try to protect the modify product template. [V1ct0r]
- Start modify product. [V1ct0r]
- Bug resolutions. [V1ct0r]
- Correct typo in home. [V1ct0r]
- Modify_shop protected in template. [V1ct0r]
- Correct typo in shop detail template. [V1ct0r]
- Useless. [V1ct0r]
- Ignore /media. [V1ct0r]
- Useless. [V1ct0r]
- Useless. [V1ct0r]
- Useless. [V1ct0r]
- Useless. [V1ct0r]
- Useless. [V1ct0r]
- Useless. [V1ct0r]
- Useless image. [V1ct0r]
- Useless image. [V1ct0r]
- Correct the typo error in profile detail template. [V1ct0r]
- Modify shop. [V1ct0r]
- Start use reverse_lazy and correct typo in home. [V1ct0r]
- Updateview for profile. [V1ct0r]
- Try hide inputfield for pin. [V1ct0r]
- Load static in shop detail template. [V1ct0r]
- List products in shop_detail template. [V1ct0r]
- Add default image for product in template. [V1ct0r]
- Add default image for shop enseigne in template. [V1ct0r]
- Continue escrow list view. [V1ct0r]
- Continue escrow list view. [V1ct0r]
- Start escrow list view. [V1ct0r]
- Update initial fixture. [V1ct0r]
- Correct typo eror. [V1ct0r]
- Upload default picture. [V1ct0r]
- Update fabfile, correction typo error in converse config. [V1ct0r]
- Add default image for avatar, add ricochet and bitmessage in account.
  [V1ct0r]
- Typo error. [V1ct0r]
- Contact page. [V1ct0r]
- First working converse.js integration. [V1ct0r]
- Templates for product listing / need to see about pagination. [V1ct0r]
- Remove commented old fonction based view for category. [V1ct0r]
- Typo correction on home, add link between shop and profile, start the
  category list view. [V1ct0r]
- Update home. [V1ct0r]
- Update urls views and templates. [V1ct0r]
- Add link to list of category. [V1ct0r]
- Add category_list. [V1ct0r]
- Add a link for the listing of the product and a link to the vendor in
  the listing. [V1ct0r]
- Class based view for create and display products, profile and shops /
  need to update. [V1ct0r]
- Add media files for default. [V1ct0r]
- Fixture for testing. [V1ct0r]
- Clean the media and the shops urls and views. [V1ct0r]
- Profile detail view with url and template. [V1ct0r]
- Add initial fixture for quick start project. [V1ct0r]
- Correction for a working create profile. [V1ct0r]
- Merge branch 'master' into dev for incluse the updates to the readme.
  [V1ct0r]
- Merge branch 'dev' with working class based view. [V1ct0r]
- Update readme. [V1ct0r]
- Update Readme. [V1ct0r]
- Update readme. [V1ct0r]
- Update REadme with link to doc for helpers. [V1ct0r]
- Update models. [V1ct0r]
- Correct the typo error and no more csrf error :) [V1ct0r]
- Correct the add_product template / csrf error always here. [V1ct0r]
- Yet debug. [V1ct0r]
- Clean the mosels and views for try resolv the errors. [V1ct0r]
- Try to resolve the csrf error and the ingrity error. [V1ct0r]
- Correct typo for tryng go oit the csrf error and delete acommented
  old-style views. [V1ct0r]
- Correct typo error for correct crsf error. [V1ct0r]
- Update home message because it was not updated??? need to correct
  style. [V1ct0r]
- Correct autoslugfield. [V1ct0r]
- Start refactoring for using class base view =>  CSRF error for add
  product. [V1ct0r]
- Class based view for add_product / permission by decorating class.
  [V1ct0r]
- Update home message style. [V1ct0r]
- Update home message, maybe it will become the about message?? [V1ct0r]
- Update home message, not very good. [V1ct0r]
- Update home message. [V1ct0r]
- Update home message. [V1ct0r]
- Start mew welcome message. [V1ct0r]
- Update profil model and template. [V1ct0r]
- Add name.field. [V1ct0r]
- Modify gitignore for don't git media uploaded by user. [V1ct0r]
- Add testing link to create and display profile. [V1ct0r]
- Working createview for profil. [V1ct0r]
- Start create view for profil. [V1ct0r]
- Add provisory link for add shop in home.html / correct link to sign In
  in base.html. [V1ct0r]
- Working CreateView for AddShopView. [V1ct0r]
- Start using create view gor add_shop. [V1ct0r]
- Add enctype=multipart/form-data to add_shop template => don't work :(
  [V1ct0r]
- Correct all list-template, need to verify all of them, add enseigne
  don't work in add_shop view. [V1ct0r]
- Try to correct the shop_list template, don't show the shops. [V1ct0r]
- Remove unused view, update add_shop need more work. [V1ct0r]
- Add view, template and url for sin_up and delete inused view. [V1ct0r]
- Remove bootstrap class dropdown of the navbar because it need
  javascript / work on shop model. [V1ct0r]
- Merge branch 'dev' of local:devmarket/fdwmarket into dev. [V1ct0r]
- Remove old template from TDD in home.html, add shop view and detail
  autoslug don't work. [V1ct0r]
- Add views, templates and url for list of shops. [V1ct0r]
- Add field likes to produc Add field views to product Add field likes
  to shop. [V1ct0r]
- Merge branch 'dev' [V1ct0r]
- Add vendor/escrows link in the templates. [V1ct0r]
- Update header for login/out link and settings.py for redirect on / at
  login. [V1ct0r]
- Correct path for login/out templates. [V1ct0r]
- Login/out templates. [V1ct0r]
- Add urls for login/out. [V1ct0r]
- Views for login from official documentation. [V1ct0r]
- Use onetoone for shop and profile name, first account form for
  authetification. [V1ct0r]
- Add_product form. [V1ct0r]
- Update yemplates for a category left side panel and correct JS path.
  [V1ct0r]
- Upgrade navbar whith login buton, update readme and todo. [V1ct0r]
- Update home page. [V1ct0r]
- Back to a basic working state with bootstrap theme. [V1ct0r]
- Bootstrap theme. [V1ct0r]
- First form for add product and link for it on the home page. [V1ct0r]
- First basic wirking form. [V1ct0r]
- Form run but render not to the good html. [V1ct0r]
- Add_category => error in the view. [V1ct0r]
- Add work on bootstrap. [V1ct0r]
- Add form for shop category and product => go test the view. [V1ct0r]
- Update forms.py. [V1ct0r]
- Forms. [V1ct0r]
- Comment the TDD form to make a new. [V1ct0r]
- Update todo. [V1ct0r]
- Update bootstrap3 and todo. [V1ct0r]
- Use base.html in category. [V1ct0r]
- Update todo. [V1ct0r]
- Update todo. [V1ct0r]
- Update links in the templates. [V1ct0r]
- Add product detail view with url and template, Todo : upgrade link in
  all templates. [V1ct0r]
- Add missing product template. [V1ct0r]
- Add class based view for display products with template and url, todo
  : link and thumbnail. [V1ct0r]
- Update fixture. [V1ct0r]
- Merge branch 'dev' of upstream:devmarket/fdwmarket into dev. [V1ct0r]
- Correct errors created by stash. [V1ct0r]
- Resolve stash conflict. [V1ct0r]
- Upgrade settings.py with media root for production and debug, add test
  pictures designed by rainmaker. [V1ct0r]
- Update Todo. [V1ct0r]
- Comment import nidecode in shop.views because we don't know if we will
  use it. [V1ct0r]
- Fixture, add utf8 in head in base.html. [V1ct0r]
- Add shop_list on home view, config settings.py to serve media uploaded
  by user in debug=True. [V1ct0r]
- Add fixture. [V1ct0r]
- Update home view and template to show the category product listed.
  [V1ct0r]
- Add url mapping for category view. [V1ct0r]
- Create category view and template for this view. [V1ct0r]
- Merge branch 'dev' of hacklab4ulibyex.oniom:devmarket/fdwmarket into
  dev. [V1ct0r]
- Add str() for return User as a string in account models. [V1ct0r]
- Add blank=True & default='' to optionnals fields in account.model, add
  str() to User foreignkey in account ans shops models. [V1ct0r]
- Add str() for return user as a string in account models. [V1ct0r]
- Add __str__ method to Account model. [V1ct0r]
- Favicon and logo from FDW. [V1ct0r]
- Update static link for namespace in shops/templates, update todo.
  [V1ct0r]
- Update requirements. [V1ct0r]
- Comment migrations in gitignore. [V1ct0r]
- Update todo. [V1ct0r]
- Update home view for use of templateResponse and update urls. [V1ct0r]
- Use spacename for static in shops, add boolean fiel isvendo on
  account. [V1ct0r]
- Change the Shop Name into foreignkey(User) [V1ct0r]
- Update account/models and register it in admin. [V1ct0r]
- Add populate. [V1ct0r]
- Update shops.models and register them in admin. [V1ct0r]
- Update home view, do not work :( [V1ct0r]
- Correct models about the migrations error base10. [V1ct0r]
- Back in woking state. [V1ct0r]
- Merge branch 'dev' of 192.168.0.29:devmarket/fdwmarket into dev.
  [V1ct0r]
- Use namespace for the templates. [V1ct0r]
- Use namespace for the templates. [V1ct0r]
- Update account models. [V1ct0r]
- Start new app account. [V1ct0r]
- Update design in the templates. [V1ct0r]
- Add home link to the about. [V1ct0r]
- Use clas based view for about and home pages. [V1ct0r]
- Working state for home/about template, maybe use another method for
  the views? [V1ct0r]
- Update templates. [V1ct0r]
- Home vienw template working. [V1ct0r]
- Correct typo error to go in a working implementation state. [V1ct0r]
- Downgrade simple views for emergency start. [V1ct0r]
- Update shops.models. [V1ct0r]
- Uncomment models for real fdw / breaking applications, test fail.
  [V1ct0r]
- Using form's own save mesthod. [V1ct0r]
- Use form in all views, back to working state. [V1ct0r]
- Rename all product name input ids and names. still broken. [V1ct0r]
- Use new form in home_page, simplify tests. NB breaks stuff. [V1ct0r]
- Using the Form in a View with a GET Request / test that should not
  pass pass ?? [V1ct0r]
- New form for shop products. [V1ct0r]
- Switching to a Django ModelForm. [V1ct0r]
- Testinh the django form api. [V1ct0r]
- Use get_absolute_url on List model to DRY urls in views / correct
  errors in tests for pass the unit tests. [V1ct0r]
- Refactor hard-coded URLs out of templates / FT ok but error in unit
  test ?? [V1ct0r]
- Enforce model validation in shop view / FT ok. [V1ct0r]
- Add the missing test / Refactor shop view to handle new product POSTs.
  [V1ct0r]
- Next Refactor: Transferring the new_item Functionality into view_list.
  [V1ct0r]
- Adjust new shop view to do model validation. [V1ct0r]
- Surfacing Model Validations Error - test ok - next : Checking Invalid
  Input Isn’t Saved to the Database. [V1ct0r]
- Use Context Manager in Unit Testing. [V1ct0r]
- Split out unit tests into two files. [V1ct0r]
- Move shops unit tests into a folder with single file. [V1ct0r]
- New test_product_validation fail. [V1ct0r]
- Update shops tests. [V1ct0r]
- Merge branch 'dev' of 192.168.0.29:devmarket/fdwmarket into dev.
  [V1ct0r]
- Split FT in multiples file, FT don(t pass. [V1ct0r]
- Split FT in multiples file. [V1ct0r]
- Typo correcton. [V1ct0r]
- Merge branch 'dev' [V1ct0r]
- Update FT with skip new test for cannot enter blank product. [V1ct0r]
- Typo correction in deploy_tools template and update provisionning
  notes. [V1ct0r]
- Typo correction. [V1ct0r]
- Typo correction in fabfile, update requirements and fabfile for
  install django1.7 from github. [V1ct0r]
- Typo correction. [V1ct0r]
- Update fabfile. [V1ct0r]
- Start fabfile for deploy_tool fabric. [V1ct0r]
- Notes & templates config files for provisioning. [V1ct0r]
- Add gunicorn to venv requirements. [V1ct0r]
- Add requirements.txt. [V1ct0r]
- Move sqlite database outside of main source tree. [V1ct0r]
- Typo correction. [V1ct0r]
- Hack FT runner to be able to test staging modify FT for python3.
  [V1ct0r]
- Update readme. [V1ct0r]
- Set STATIC_ROOT in settings.py and disable admin. [V1ct0r]
- Use Bootstrap to improve layout. [V1ct0r]
- Refactor template to use a base template. [V1ct0r]
- First steps of FT for layout + styling. [V1ct0r]
- Minimal site ok unit test & FT ok - chap 6 ended. [V1ct0r]
- New URL + view for adding to existing shops. FT passes :) [V1ct0r]
- New url to reach the rest of the world - work in progress 8. [V1ct0r]
- New url to reach the rest of the world - work in progress 7. [V1ct0r]
- New url to reach the rest of the world - work in progress 6. [V1ct0r]
- New url to reach the rest of the world - work in progress 5. [V1ct0r]
- New url to reach the rest of the world - work in progress 4. [V1ct0r]
- New url to reach the rest of the world - work in progress 3. [V1ct0r]
- New url to reach the rest of the world - work in progress 2. [V1ct0r]
- New url to reach the rest of the world - work in progress. [V1ct0r]
- Update class ShopViewTest. [V1ct0r]
- Update todo in readme. [V1ct0r]
- New shop for every single new product submission- display all products
  like they come on the same shop. [V1ct0r]
- Change the POST request in shop.html. [V1ct0r]
- New url test ok. [V1ct0r]
- New shops_urls debug. [V1ct0r]
- Upgrade TODO in README. [V1ct0r]
- Upgrade TODO in README. [V1ct0r]
- New URL, view and template to displays shops. [V1ct0r]
- Correct the bad url in tests.py, test ok. [V1ct0r]
- Try to pass the test. [V1ct0r]
- Modify home.html for fail like the test like expected. [V1ct0r]
- Update shops/models.py. [V1ct0r]
- New app shops breack the tests. [V1ct0r]
- New url for app shop corrections. [V1ct0r]
- Change app products to shop test ok. [V1ct0r]
- Change app products to shops. [V1ct0r]
- Need to refactoring the new shop url before go to a new test
  class(chap 6) [V1ct0r]
- Typo correction, python2 compatibility for FT. [V1ct0r]
- Typo correction. [V1ct0r]
- Typo correction. [V1ct0r]
- Upgrade FT. [V1ct0r]
- Redirect after Post and show all products in template. [V1ct0r]
- POST test is not too long now. [V1ct0r]
- Test redirect after post ok. [V1ct0r]
- Typo correction. [V1ct0r]
- Chapitre 5 saving POST to DB - test fail. [V1ct0r]
- Marquetapage. [V1ct0r]
- Model for products and associated migrations. [V1ct0r]
- Add our products/models but commanted for following test. [V1ct0r]
- Refactor the FT. [V1ct0r]
- Now fail the functionnal test. [V1ct0r]
- Pass the FT add and show a product(text only) [V1ct0r]
- Correct typo to ft. [V1ct0r]
- Correct typo in tests.py. [V1ct0r]
- Use LiveServerTestCase. [V1ct0r]
- Front page HTML now generated from a template. [V1ct0r]
- Typo correction. [V1ct0r]
- Update home.html. [V1ct0r]
- Refactor home page view to use a template. [V1ct0r]
- Add news test and start using views. [V1ct0r]
- Import future in the tests. [V1ct0r]
- FT check now, we can enter a product, bakup FT0 as a TODO. [V1ct0r]
- Update README with groups. [V1ct0r]
- Test request home ok. [V1ct0r]
- Update functionnal_test / add import from futur for python2/3
  compatibility. [V1ct0r]
- New failed test_home_returns_correct_html. [V1ct0r]
- First unit test and url mapping, dummy view. [V1ct0r]
- Move tests in the good place(error in last commit) [V1ct0r]
- Startapp product & first unit test. [V1ct0r]
- Update .gitignore. [V1ct0r]
- Update .gitignore. [V1ct0r]
- Update .gitignore, start django-project. [V1ct0r]
- Add .gitignore. [V1ct0r]
- Initial commit. [V1ct0r]
